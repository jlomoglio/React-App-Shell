import React, { module } from "react";
import styles from './Footer.module.css';

const Footer = () => {
    return (
        <div className={styles['footer']}>
            <span>
                Alpine Software © 2023, All rights reserved.
            </span>
        </div>
    );
};

export default Footer;