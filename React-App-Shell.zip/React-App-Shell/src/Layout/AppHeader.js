import React, { module, Fragment, use } from "react";
import { useSelector } from "react-redux";
import styles from './AppHeader.module.css';
import reactLogo from '../Components/Icons/react.png';


export default function AppHeader () {
    
    const appHeaderStyles = {
        position: 'absolute',
        left: '115px',
        right: '0px',
        top: '0px',
        height: '42px',
        backgroundColor: '#fff',
        bottomBorder: '1px solid #ccc',
    }

    return (
        <Fragment>
            <header className={styles['app-header']}>
                <span>App Header</span>
            </header>
        </Fragment>
    );
};