import React, {Fragment} from "react";
import { Outlet } from "react-router-dom";
import { useSelector } from "react-redux";
import Footer from "./Footer";
import Header from "./Header";
import AppHeader from '../Layout/AppHeader';
import LeftPanel from '../Layout/LeftPanel';

export default function Layout () {

    const loggedIn = useSelector(state => state.app.isLoggedIn)

    return(
        <Fragment>
            {loggedIn === true && (
                <Fragment>
                    <LeftPanel />
                    <div style={{position: 'absolute', left: '155px', right: '0px', bottom: '0px', top: '0px'}}>
                        <AppHeader />
                        <div style={{position: 'absolute', top: '40px', padding: '15px'}}><Outlet /></div>
                    </div>
                </Fragment>
            )}
            {loggedIn === false && (
                <Fragment>
                    <Header type="app" /> 
                    <Outlet /> 
                    <Footer />
                </Fragment>
            )}
        </Fragment> 
    )
}