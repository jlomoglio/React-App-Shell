import React, { module, Fragment, use } from "react";
import { useSelector } from "react-redux";
import styles from './Header.module.css';
import reactLogo from '../Components/Icons/react.png';


const Header = (props) => {
    const loginHeaderStyles = {
        width: '100%',
        height: '80px',
        backgroundColor: '#fff',
    }

    const appHeaderStyles = {
        width: '100%',
        height: '52px',
        backgroundColor: '#3c3c3e',
    }

    return (
        <Fragment>
            {props.type === 'login' && (
                <header className={styles['header']} styles={loginHeaderStyles}>
                    <img src={reactLogo} className={styles['logo']} />
                    <div className={styles['title']}>Customer Business Name</div>
                </header>
            )}
        </Fragment>
    );
};

export default Header;