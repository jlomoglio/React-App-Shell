import React from 'react';

export default function NoPage(){
    return(
        <div>404 Page not available</div>
    )
}