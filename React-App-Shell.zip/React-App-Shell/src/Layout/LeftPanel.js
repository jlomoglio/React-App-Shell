import React, { useState, useRef, useEffect, Fragment } from "react";
import { useLocation } from "react-router";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import styles from './LeftPanel.module.css';
import Logo from '../Components/Images/alpine-logo.png';
import Dashboard from '../Components/Icons/dashboard.png';
import DashboardSelected from '../Components/Icons/dashboard-selected.png';
import Facility from '../Components/Icons/office-building.png';
import FacilitySelected from '../Components/Icons/office-building-selected.png';
import Security from '../Components/Icons/lock.png';
import SecuritySelected from '../Components/Icons/lock-selected.png';
import Documents from '../Components/Icons/document.png';
import DocumentsSelected from '../Components/Icons/document-selected.png';
import Contractor from '../Components/Icons/contractor.png';
import ContractorSelected from '../Components/Icons/contractor-selected.png';
import Knowledge from '../Components/Icons/knowledge.png';
import KnowledgeSelected from '../Components/Icons/knowledge-selected.png';
import Message from '../Components/Icons/message.png';
import MessageSelected from '../Components/Icons/message-selected.png';
import Tasks from '../Components/Icons/clipboard.png';
import TasksSelected from '../Components/Icons/clipboard-selected.png';
import Project from '../Components/Icons/folder.png';
import ProjectSelected from '../Components/Icons/folder-selected.png';

/** REDUX STATE ACTIONS ********************************/
import { uiActions } from "../Store/ui-slice";
import { appActions } from "../Store/app-slice";

export default function LeftPanel () {

    /** Setup Dispatch & Location */
    const dispatch = useDispatch();
    const location = useLocation();
    const navigate = useNavigate();

    const [selectedMenu, setSelectedMenu] = useState("dashboard");
    const [menuHovered, setMenuHovered] = useState(false); 

    const toggleMenu = (id, name) => {
        //setSelectedMenu(name);
        const ele = document.getElementById(id);
        ele.style.backgroundColor = "rgb(238, 242, 242)";
        setMenuHovered(!menuHovered)
    }

    const loadView = (path, view) => {
        navigate("/" + path);
        dispatch(appActions.setView());
        setSelectedMenu(view);
    }

    return (
        <Fragment>
            <div id="panel-container" className={styles['panel-container']}>
                <div id="logo-wrapper" className={styles['logo-wrapper']}>
                    <img src={Logo} alt="" className={styles['logo']} />
                </div>

                {/** DASHBOARD MENU ITEM */}
                <div id="menu-dashboard" className={selectedMenu === 'dashboard' ? styles['menu-item-selected'] : styles['menu-item']} onClick={() => loadView("Dashboard", "dashboard")}>
                    <div className={selectedMenu === 'dashboard' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']}>
                            <img src={selectedMenu === 'dashboard' ? DashboardSelected : Dashboard} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'dashboard' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Dashboard</div>
                        </div>
                    </center>
                </div>

                {/** FACILITY MANAGEMENT MENU ITEM */}
                <div id="menu-facility" className={selectedMenu === 'facility' ? styles['menu-item-selected'] : styles['menu-item']} style={{paddingBottom: "15px"}} onClick={() => loadView("FacilityManagement", "facility")}>
                    <div className={selectedMenu === 'facility' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']} style={{marginLeft: '20px'}}>
                            <img src={selectedMenu === 'facility' ? FacilitySelected : Facility} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'facility' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Facility <br /> Management</div>
                        </div>
                    </center>
                </div>

                {/** SECURITY MENU ITEM */}
                <div id="menu-security" className={selectedMenu === 'security' ? styles['menu-item-selected'] : styles['menu-item']} onClick={() => loadView("Security", "security")}>
                    <div className={selectedMenu === 'security' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']} style={{marginLeft: '40px'}}>
                            <img src={selectedMenu === 'security' ? SecuritySelected : Security} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'security' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Security</div>
                        </div>
                    </center>
                </div>

                {/** DOCUMENTS MENU ITEM */}
                <div id="menu-documents" className={selectedMenu === 'documents' ? styles['menu-item-selected'] : styles['menu-item']} onClick={() => loadView("Documents", "documents")}>
                    <div className={selectedMenu === 'documents' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']}>
                            <img src={selectedMenu === 'documents' ? DocumentsSelected : Documents} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'documents' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Documents</div>
                        </div>
                    </center>
                </div>

                {/** SUBCONTRACTOR MENU ITEM */}
                <div id="menu-contractors" className={selectedMenu === 'contractors' ? styles['menu-item-selected'] : styles['menu-item']}>
                    <div className={selectedMenu === 'contractors' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']} style={{marginLeft: '18px'}}>
                            <img src={selectedMenu === 'contractors' ? ContractorSelected : Contractor} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'contractors' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Subcontractors</div>
                        </div>
                    </center>
                </div>

                {/** KNOWLEDGE BASE MENU ITEM */}
                <div id="menu-knowledge" className={selectedMenu === 'knowledge' ? styles['menu-item-selected'] : styles['menu-item']}>
                    <div className={selectedMenu === 'knowledge' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']} style={{marginLeft: '15px'}}>
                            <img src={selectedMenu === 'knowledge' ? KnowledgeSelected : Knowledge} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'knowledge' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Knowledge Base</div>
                        </div>
                    </center>
                </div>

                {/** MESSAGES MENU ITEM */}
                <div id="menu-messages" className={selectedMenu === 'messages' ? styles['menu-item-selected'] : styles['menu-item']}>
                    <div className={selectedMenu === 'messages' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']} style={{marginLeft: '35px'}}>
                            <img src={selectedMenu === 'messages' ? MessageSelected : Message} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'messagess' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Messages</div>
                        </div>
                    </center>
                </div>

                {/** TASKS MENU ITEM */}
                <div id="menu-tasks" className={selectedMenu === 'tasks' ? styles['menu-item-selected'] : styles['menu-item']}>
                    <div className={selectedMenu === 'tasks' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']} style={{marginLeft: '49px'}}>
                            <img src={selectedMenu === 'tasks' ? TasksSelected : Tasks} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'tasks' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Tasks</div>
                        </div>
                    </center>
                </div>

                {/** PROJECT VIEW MENU ITEM */}
                <div id="menu-project" className={selectedMenu === 'project' ? styles['menu-item-selected'] : styles['menu-item']}>
                    <div className={selectedMenu === 'project' ? styles['selected-bar'] : styles['selected-bar-hidden']}></div>
                    <center>
                        <div className={styles['icon-wrapper']} style={{marginLeft: '30px'}}>
                            <img src={selectedMenu === 'project' ? ProjectSelected : Project} alt="" className={styles['menu-item-icon']} />
                            <div className={selectedMenu === 'project' ? styles['menu-item-label-selected'] : styles['menu-item-label']}>Project View</div>
                        </div>
                    </center>
                </div>
            </div>
        </Fragment>
    )
}