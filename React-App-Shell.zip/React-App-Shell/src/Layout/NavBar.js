import React from "react";
import styles from './NavBar.module.css';
import NavItems from './NavItems';
import { useSelector } from "react-redux";

export default function NavBar(props) {
    const title = useSelector(state => state.ui.pageTitle)

    return (
        <div className={styles.navbar}>
            <div id="navbarPageTitle" className={styles['page-title']}>Sub Nav/Title Bar</div>
        </div>  
    );
};