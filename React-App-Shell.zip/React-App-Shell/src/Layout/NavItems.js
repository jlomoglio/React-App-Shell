import React from "react";
import { Link } from "react-router-dom";
import styles from './NavItems.module.css';


const NavItems = () => {

    // const [isActiveQueue, setIsActiveQueue] = useState(false)
    // const [isActivePharmacy, setIsActivePharmacy] = useState(false)
    // const [isActiveProducts, setIsActiveSTemps] = useState(false)
    // const [isActiveReports, setIsActiveCTemps] = useState(false)

    const links = [
        { id: "queueLink", name: "Request Queue", to: "/" },
        { id: "pharmacyLink", name: "Manage Pharmacy Topics", to: "ManagePharmacyTopics" },
        { id: "productsLink", name: "Manage Products & Services", to: "ManageProductsAndServices" },
        { id: "reportsLink", name: "Reporting Dashboard", to: "ReportingDashboard" },
    ]

    const handleClick = (id) => {
        /** Loop through the number of links and set link class to default */
        links.map((link, index) => {
            return document.getElementById(link.id).className = `${styles[""]}`
        })

        /** Set selected link class */
        document.getElementById(id).className = `${styles["active"]}`
    }

    return (
        <div className={styles['nav-items-container']}>
            <ul>
                { links.map((link, index) => (
                    <li key={index} id={link.id} onClick={() => handleClick(link.id)} className={link.id === 'queueLink' ? styles['active'] : null}>
                        <Link key={Math.random()} to={link.to}>{link.name}</Link>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default NavItems;