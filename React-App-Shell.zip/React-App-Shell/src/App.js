import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./Layout/Layout";
import Login from "./Pages/Login/Login";
import Dashboard from './Pages/Dashboard/Dashboard';
import FacilityManagement from './Pages/FacilityManagement/FacilityManagement';
import Security from './Pages/Security/Security';
import Documents from './Pages/Documents/Documents';


export default function App() {

  return (
    <BrowserRouter>
      <Routes>
        {/** Loads the layout for the apllication */}
        <Route path="/" element={<Layout />}>

          {/** Route Paths */}
          <Route index element={<Login />} />
          <Route path="Dashboard" element={<Dashboard />} />
          <Route path="FacilityManagement" element={<FacilityManagement />} />
          <Route path="Security" element={<Security />} />
          <Route path="Documents" element={<Documents />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
