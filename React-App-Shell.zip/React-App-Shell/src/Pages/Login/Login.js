import React, { useState, useRef, useEffect, Fragment } from "react";
import styles from './Login.module.css';
import backgroundImage from '../../Components/Images/background.jpg';
import alpineLogo from '../../Components/Images/alpine-logo.png';
import showIcon from '../../Components/Icons/show.png';
import hideIcon from '../../Components/Icons/invisible.png';


export default function Login () {
    /** Local state for hiding & showing password */
    const [showPassword, setShowPassword] = useState(false);

    /** JSON CSS STYLE - need to use so we can dynamically add the background image */
    const loginPageContainerStyles = {
        backgroundImage: `url(${backgroundImage})`,
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        opacity: '0.7',
        position: 'fixed',
        top: '80px',
        bottom: '50px',
        left: '20px',
        right: '20px',
    };

    const toggle = () => {
        setShowPassword(!showPassword);
    }

    return (
        <Fragment>
            <div id="login-page-container" style={loginPageContainerStyles}>

                <div id="login-card" className={styles['login-card']}>

                    <div id="login-card-header" className={styles['login-card-header']}>
                        <center><img src={alpineLogo} alt="" /></center>
                    </div>

                    <div id="login-form" className={styles['login-form']}>
                        <div className={styles['form-sub-header']}>Log in to your account</div>

                        <input type="email" id="email-input" placeholder="Email" className={styles['input']} autoFocus />

                        <div id="password-wrapper">
                            <input type={showPassword === true ? "password" : "text"} id="password-input" placeholder="Password" className={styles['password-input']} />
                            <div id="hide-show-icon-wrapper" className={styles['hide-show-icon-wrapper']}>
                                {showPassword === false ? (
                                    <img src={showIcon} alt="" className={styles['icon-show']} onClick={toggle} />
                                ) : (
                                    <img src={hideIcon} alt="" className={styles['icon-hide']} onClick={toggle} />
                                )}
                                
                            </div>
                        </div>

                        <input type="button" id="password-input" placeholder="Password" className={styles['button']} value="LOG IN" />

                        <div className={styles['form-forgot-label']}>Forgot password?</div>
                    </div>

                </div>

            </div>
            <div className={styles['login-footer']}>
                <span>
                    Alpine Software © 2023, All rights reserved.
                </span>
            </div>
        </Fragment>
    )
}