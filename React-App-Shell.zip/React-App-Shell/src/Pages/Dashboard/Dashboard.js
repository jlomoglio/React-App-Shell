import React, { useState, useRef, useEffect, Fragment } from "react";
import styles from './Dashboard.module.css';

export default function Dashboard () {


    return (
        <Fragment>
            <h1>DASHBOARD</h1>
        </Fragment>
    )
}