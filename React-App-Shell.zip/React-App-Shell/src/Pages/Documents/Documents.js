import React, { useState, useRef, useEffect, Fragment } from "react";
import styles from './Documents.module.css';

export default function Documents () {


    return (
        <Fragment>
            <h1>Documents</h1>
        </Fragment>
    )
}