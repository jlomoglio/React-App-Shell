import React, { useState, useRef, useEffect, Fragment } from "react";
import styles from './FacilityManagement.module.css';

export default function FacilityManagement () {


    return (
        <Fragment>
            <h1>FACILITY MANAGEMENT</h1>
        </Fragment>
    )
}