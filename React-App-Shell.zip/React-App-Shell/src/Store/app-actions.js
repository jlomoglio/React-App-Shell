import { appActions } from './app-slice';

/** API FUNCTION CALLS GO HERE */
export const fetchRequestData = () => {
    
};