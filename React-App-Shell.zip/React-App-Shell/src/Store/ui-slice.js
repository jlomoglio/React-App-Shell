import { createSlice } from '@reduxjs/toolkit';

const uiSlice = createSlice({
  name: 'ui',
  initialState: { 
      pageTitle: 'Request Queue',
    },
    reducers: {
        setPageTitle(state, action) {
            state.pageTitle = action.payload;
        },
    },  
});

export const uiActions = uiSlice.actions;
export default uiSlice;
