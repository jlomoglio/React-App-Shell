import { createSlice } from '@reduxjs/toolkit';

const appSlice = createSlice ({
    name: 'app',
    initialState: {
        isLoggedIn: true,
        view: "",
    },
    reducers: {
        /** Loads requests from database */
        submitLogin(state, action) {
            state.isLoggedIn = action.payload;
        },

        setView(state, action) {
            state.view = action.payload;
        }
        
    },
});

export const appActions = appSlice.actions;
export default appSlice;