import React, { useState, useRef, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useLocation } from "react-router";
import { useNavigate } from "react-router-dom";
import { useDebugState } from "use-named-state";
import style from './Form.module.css';
import Card from "../UI/Card";
import Input from '../UI/Input';
import Checkbox from '../UI/Checkbox';
import Radio from '../UI/Radio';
import FileUpload from "../UI/FileUpload";
import FormSelect from "../UI/FormSelect";
import SelectMultiple from "../UI/SelectMultiple";
import DatePicker from '../UI/DatePicker';
import SelectStates from '../UI/SelectStates';
import Button from "../UI/Button";
import AplhaFilterBar from "../UI/AlphaFilterBar";
import leftArrowsIcon from "../Icons/left-double-chevron.png";
import rightArrowsIcon from "../Icons/right-double-chevron.png";
import leftArrowsIconDisabled from "../Icons/left-double-chevron-disabled.png";
import rightArrowsIconDisabled from "../Icons/right-double-chevron-disabled.png";

/** REDUX STATE ACTIONS */
import { uiActions } from "../../Store/ui-slice";
import { requestActions } from "../../Store/app-slice";


export default function FormAdd() {

    /** Setup Dispatch & Location */
    const dispatch = useDispatch();
    const location = useLocation();

    /** Setup Naviagtion and Location state */
    const navigate = useNavigate();
    const formSystem = location.state.system;

    // TEMP AUTO GENERATE REQUEST NUMBER
    const requestNum = Math.random().toString().slice(2,11)


    // TEMP USER INFO //////////////////////////////////
    let userName = "Jane Doe";
    let userEmail = "jane.doe@uhc.com";
    ////////////////////////////////////////////////////

    /**
     * Set Page Title
     */
    let system;
    useEffect(() => {
        if (formSystem === "Both") { system = "CTM / Omni" }
        if (formSystem === "CTM") { system = "CTM" }
        if (formSystem === "Omni") { system = "Omni" }
        dispatch(uiActions.setPageTitle(system + " Add File Asset"));

        /** Scrolls page to top if refreshed */
        window.onbeforeunload = function () {
            window.scrollTo(0, 0);
        }
        
    }, [dispatch, system, formSystem])


    ////// TEMP DATES /////////////////////
    const last_Verified_Date = "12/14/2022";
    ///////////////////////////////////////

    /** Today's Date */
    const date = new Date();
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    const request_date = `${month}/${day}/${year}`;

    /** 
     * Gets form field options data from redux state request-slice 
     */
    // WORK WITH ERIC TO PULL FROM API AND NOT REDUX //////////////////////////////////////////////
    const lobCustomerSegmentOptions = useSelector(state => state.requests.lobCustomerSegmentOptions);
    const productServicesOptions = useSelector(state => state.requests.productServicesOptions);
    const audienceOptions = useSelector(state => state.requests.audienceOptions);
    const brandDivisionOptions = useSelector(state => state.requests.brandDivisionOptions);
    const ctmDocumentTypeOptions = useSelector(state => state.requests.ctmDocumentTypeOptions);
    const omniDocumentTypeOptions = useSelector(state => state.requests.omniDocumentTypeOptions);
    const pharmacyTopicTypeOptions = useSelector(state => state.requests.pharmacyTopicTypeOptions);
    const ctmBenefitTypeOptions = useSelector(state => state.requests.ctmBenefitTypeOptions);
    const omniBenefitTypeOptions = useSelector(state => state.requests.omniBenefitTypeOptions);
    const fundingTypeOptions = useSelector(state => state.requests.fundingTypeOptions);
    const prePostEnrollmentOptions = useSelector(state => state.requests.fundingTypeOptions);
    const ctmBusinessUnitOptions = useSelector(state => state.requests.ctmBusinessUnitOptions);
    const omniBusinessUnitOptions = useSelector(state => state.requests.omniBusinessUnitOptions);
    const languageOptions = useSelector(state => state.requests.languageOptions);


    /***********************************************************************************
     * LOCAL STATE
     ************************************************************************************/

    /** 
     * Character Counts 
     * */
    const [totalCharactersCtmTopic, setTotalCharactersCtmTopic] = useState();
    const [totalCharactersKeywords, setTotalCharactersKeywords] = useState();

    /** 
     * Toggles 
     * */
    const [openRushComments, setOpenRushComments] = useState(false);
    const [lobSelectedOptions, setLobSelectedOptions] = useDebugState("lobSelectedOptions", []);
    const [lobSelectedOptionIDs, setLobSelectedOptionIDs] = useDebugState("lobSelectedOptionIDs", []);

    /** 
     * Added Options
     * */
    const [addedLob, setAddedLob] = useDebugState("addedLob", []);
    const [addedAudienceId, setAddedAudienceId] = useDebugState("addedAudienceId", "");
    const [addedBrandDivisionId, setAddedBrandDivisionId] = useDebugState("addedBrandDivisionId", "");
    const [addedCtmDocumentTypeId, setAddedCtmDocumentTypeId] = useDebugState("addedCtmDocumentTypeId", "");
    const [addedOmniDocumentTypeId, setAddedOmniDocumentTypeId] = useDebugState("addedOmniDocumentTypeId", "");
    const [addedPharmacyTopicTypeId, setAddedPharmacyTopicTypeId] = useDebugState("addedPharmacyTopicTypeId", "");
    const [addedCtmBenefitTypeId, setAddedCtmBenefitTypeId] = useDebugState("addedCtmBenefitTypeId", "");
    const [addedOmniBenefitTypeId, setAddedOmniBenefitTypeId] = useDebugState("addedOmniBenefitTypeId", "");
    const [addedFundingTypeId, setAddedFundingTypeId] = useDebugState("addedFundingTypeId", "");
    const [addedPrePostEnrollmentId, setAddedPrePostEnrollmentId] = useDebugState("addedPrePostEnrollmentId", "");
    const [addedCtmBusinessUnitId, setAddedCtmBusinessUnitId] = useDebugState("addedCtmBusinessUnitId", "");
    const [addedOmniBusinessUnitId, setAddedOmniBusinessUnitId] = useDebugState("addedOmniBusinessUnitId", "");
    const [addedLanguageId, setAddedLanguageId] = useDebugState("addedLanguageId", "");

    /** 
     * Products / Services 
     * */
    const [iconLeft, setIconLeft] = useState(leftArrowsIconDisabled);
    const [iconRight, setIconRight] = useState(rightArrowsIconDisabled);
    const [isAddButtonDisabled, setIsAddButtonDisabled] = useState(true);
    const [isRemoveButtonDisabled, setIsRemoveButtonDisabled] = useState(true);
    const [addedProductServices, setAddedProductServices] = useDebugState("addedProductServices", []);

    /** 
     * US States (not local or redux state) 
     * */
    const [stateSelectedOptions, setStateSelectedOptions] = useState([]);
    

    /***********************************************************************************
     *  FORM FUNCTIONS
     ************************************************************************************/

    /** Uploads PDF */
    const handleUploadedFilePdf = () => {}

    /** Uploads Omni High Res PDF */
    const handleUploadedFileOmniHighResPdf = () => {}

    /** Toggles Rush Comments */
    const handleToggleRushComments = () => {
        setOpenRushComments(!openRushComments);
    }

    /** Name Validation */
    const validateNames = (event) => {
        let key = event.key;
        let regex = /[0-9]|\./;
        if (regex.test(key)) {
            event.preventDefault();
        }
    }

    /** Validate Value Length */
    const validateValueLength = (count, field) => {
        /** Define formfield element */
        const ele = document.getElementsByName(field);

        /** Limit the number of chars that can be entered */
        if(ele[0].value.length > count) {
            ele[0].value = ele[0].value.substr(0, count);
            ele[0].value.slice(0, count);
        }

        /** Update the total characters counter */
        field === "keywords" && setTotalCharactersKeywords(ele[0].value.length);
        field === "ctm-topic" && setTotalCharactersCtmTopic(ele[0].value.length);
    }

    /** Validate Email */
    const validateLettersOnly = (value) => {
        if (/^[a-zA-Z]*$/.test(value)) {
            return true;
        }
    }


    /***********************************************************************************
     *  ADDS OPTION ID'S
     ************************************************************************************/

    /** Adds LOB Values to state */
    const handleSelectedValuesLob = (options, ids) => {
        if (formSystem === "CTM" || formSystem === "Both") {
            /** Add values to Lob field */
            const ele = document.getElementById("lobForProdServ");
            ele.setAttribute('value', options.toString().split(',').join(', '));
            setLobSelectedOptions(options.toString().split(',').join(', '));
            setLobSelectedOptionIDs(ids);
        }
        else if (formSystem === "Omni") {
            setLobSelectedOptionIDs(ids);
        }
    }

    /** Adds Audience Value to state */
    const handleSelectedValuesAudience = (id) => {
        setAddedAudienceId(id);
    }

    /** Adds Brand Division Value to state */
    const handleSelectedValuesBrand = (id) => {
        setAddedBrandDivisionId(id);
    }

    /** Adds CTM Document Type Value to state */
    const handleSelectedValuesCtmDocumentType = (id) => {
        setAddedCtmDocumentTypeId(id);
    }

    /** Adds Omni Document Type Value to state */
    const handleSelectedValuesOmniDocumentType = (id) => {
        setAddedOmniDocumentTypeId(id);
    }

    /** Adds Omni Benift Type Value to state */
    const handleSelectedValuesOmniBenefitType = (id) => {
        setAddedOmniBenefitTypeId(id);
    }

    /** Adds Pharmacy Topic Type Value to state */
    const handleSelectedValuesPharmacyDocumentType = (id) => {
        setAddedPharmacyTopicTypeId(id);
    }

    /** Adds CTM Bebefit Type Value to state */
    const handleSelectedValuesCtmBenefitType = (id) => {
        setAddedCtmBenefitTypeId(id);
    }

    /** Adds Funding Type Value to state */
    const handleSelectedValuesFundingType = (id) => {
        setAddedFundingTypeId(id);
    }

    /** Adds States Values to state => MOVE TO REDUX */
    const handleStateOptions = (states) => {
        setStateSelectedOptions(states);
    }

    /** Adds CTM Business Unit Value to state */
    const handleSelectedValuesCtmBusinessUnit = (id) => {
        setAddedCtmBusinessUnitId(id);
    }

    /** Adds Pre Post Enrollment Value to state */
    const handleSelectedValuesPrePostEnrollment = (id) => {
        setAddedPrePostEnrollmentId(id);
    }

    /** Adds Language Value to state */
    const handleSelectedValuesLanguage = (id) => {
        setAddedLanguageId(id);
    }

    /** Toggles Date Picked */
    const triggerDateOpen = (event) => {
        event.target.showPicker();
    }


    /*********************************************************************************** 
     *  START: PRODUCTS / SERVICES FUNCTIONS
     ***********************************************************************************/
    const productRow = useRef([]);

    /** Enables the products/ services Add button */
    const toggleAddButtonSelected = () => {
        setIsAddButtonDisabled(false);
        setIconRight(rightArrowsIcon);
    }

    /** Disables the products / services Add button */
    const toggleAddButtonUnselected = () => {
        if (addProductsServices.length === 1) {
            setIsAddButtonDisabled(true);
            setIconRight(rightArrowsIconDisabled);
        }
    }

    /** Enables the products/ services Remove button */
    const toggleRemoveButtonSelected = () => {
        setIsRemoveButtonDisabled(false);
        setIconLeft(leftArrowsIcon);
    }

    /** Disables the products / services Add button */
    const toggleRemoveButtonUnselected = () => {
        if (addProductsServices.length === 1) {    
            setIsAddButtonDisabled(true);
            setIconLeft(leftArrowsIconDisabled);
        }
    }

    /** Handles selecting/Unselecting rows. */
    const handleProductSelectedRow = (id, name) => {
        /** Prevent disabled rows from being clicked */
        if (productRow.current[id].getAttribute('data-disabled') === "no") {
            
            /** Check to see if there is an id */
            if (id.indexOf(id !== null)) {
                /** 
                 * Selected row data object.
                 * Assings id and name to the selected products/services being added 
                 * to the added list
                 * */
                const prodServRow = {id: id, value: name}

                /** 
                 * Select the current row 
                 * */
                if (productRow.current[id].getAttribute('data-selected') === "no") {
                    
                    /** The row is selected so change the row style & set the attr to yes */
                    productRow.current[id].setAttribute('data-selected', "yes");
                    productRow.current[id].style.backgroundColor = "rgba(182, 207, 243, 0.805)";

                    /** Add the selected row data to state. */
                    setAddedProductServices(addedProductServices => [...addedProductServices, prodServRow]);

                    /** Enables the Add Button */
                    toggleAddButtonSelected();
                }
                /** 
                 * Unselect the current row 
                 * */
                else if (productRow.current[id].getAttribute('data-selected') === "yes") {
                    
                    /** The row is deslected so change the row style back to default */
                    productRow.current[id].setAttribute('data-selected', "no");

                    /** Set the row background color based on if it is even or odd */
                    if (id % 2 == 0) {
                        productRow.current[id].style.backgroundColor = "#F4F4F4";
                    }
                    else {
                        productRow.current[id].style.backgroundColor = "#FFF";
                    }

                    /** Remove selected product row data from state */
                    setAddedProductServices(addedProductServices.filter(prod => prod.id !== id));
                    /** Remove the id of the product that's been clicked */

                    /** Disables the Add Button */
                    toggleAddButtonUnselected();
                }; 
            }
        }
    }

    /** Handles selecting/unselecting added rows in the list on the right. */
    const handleProductSelectedAddedRow = (id) => {
        if (id.indexOf(id !== null)) {
            
            /** 
             * Select the current row 
             * */
            if (document.getElementById("addedRow_" + id).getAttribute('data-selected') === "no") {

                /** The row is selected so change the row style & set the attr to yes */
                document.getElementById("addedRow_" + id).setAttribute('data-selected', "yes");
                document.getElementById("addedRow_" + id).style.backgroundColor = "rgba(182, 207, 243, 0.805)";

                /** Toggles Add Button */
                toggleRemoveButtonSelected();
                
            }
            else if (document.getElementById("addedRow_" + id).getAttribute('data-selected') === "yes") {
                
                /** The row is selected so change the row style & set the attr to no */
                document.getElementById("addedRow_" + id).setAttribute('data-selected', "no");

                /** Check if row is even or odd */
                if (id % 2 == 0) {
                    document.getElementById("addedRow_" + id).style.backgroundColor = "#F4F4F4";
                }
                else {
                    document.getElementById("addedRow_" + id).style.backgroundColor = "#FFF";
                }

                /** Toggles Add Button */
                toggleRemoveButtonSelected();

                /** Remove all removed rows from local state */
                setAddedProductServices(addedProductServices.filter(item => item.id !== id));
            }
        }
    }

    /**
     *  Populates the selected products/services list with the selected items.
     *  It also disables the selected items and the add button.
     */

    /** Adds product row to list on right side and disables products in the list on the left */
    const addProductsServices = (existingProductVals) => { 
        
        /** If an error for a blank value is set, clear them */
        clearProdError();
        
        /** Thge product has been added to the list on the right, no disable the Add button */
        setIsAddButtonDisabled(true);
        setIconRight(rightArrowsIconDisabled);

        /** Define the list element on the right */
        let list = document.getElementById('addedList');
        
        /** 
         * Loop through the selected products & services to be added to the list.
         * If this is an existing request then load request data, otherwise just
         * add the new products being added. 
         */
        let prdoServ;
        
        if (existingProductVals) {
            if (existingProductVals.length > 0) {
                prdoServ = existingProductVals
            }
        }
        else {
            prdoServ = addedProductServices;
        }
        
        prdoServ.map((ps) => {

            /** Check if product / service is already in the list */
            if (!list.querySelector("#addedRow_" + ps.id)) {
                
                /** Create row for the list products to be added */
                let row = document.createElement('div');
                row.id = "addedRow_" + ps.id;
                row.className = style['list-row'];
                row.setAttribute('data-selected', 'no');
                row.addEventListener("click", () => handleProductSelectedAddedRow(ps.id));

                /** Create the wrapper for the product name */
                let productNameWrapper = document.createElement('div');
                productNameWrapper.className = style['product-name'];
                productNameWrapper.innerHTML = ps.value;
                
                /** Append the wrapper to the row */
                row.appendChild(productNameWrapper)

                /** Add the row to the list */
                list.appendChild(row);
            
                /** Disbale the selected product rows on the left */
                let productRow = document.getElementById(ps.id);
                productRow.style.backgroundColor = "rgba(191, 192, 194, 0.805)";
                productRow.style.cursor = "default";
                productRow.setAttribute('data-disabled', 'yes');
            }
        })
    }

    /** Enables products in list that were selected and disabled and now are removed from the list on the right. */
    const enableProductOptionRows = (id) => {
        
        /** sets the default row color based on if it is even or odd */
        if (id % 2 === 0) {
            document.getElementById(id).setAttribute('style', '{backgroundColor: #F4F4F4, cursor: pointer}');
            document.getElementById(id).setAttribute('data-disabled', 'no');
        }
        else {
            document.getElementById(id).setAttribute('style', '{backgroundColor: #FFF, cursor: pointer}');
            document.getElementById(id).setAttribute('data-disabled', 'no');
        }

        /** Add click event listener to make sure the re-enabled rows are clickable */
        productRow.current[id].addEventListener('click', () => handleProductSelectedRow(id));

        /** Remove preveiously selected row from local state */
        setAddedProductServices(addedProductServices.filter(item => item.id !== id));
    }

    /** Removes the added products / services from list on the right. */
    const removeProductsAddedRow = () => {
            setIsRemoveButtonDisabled(true);
            toggleRemoveButtonUnselected();
            
        /** Set the list element */
        let list = document.getElementById('addedList');

        /** Get all the selected added rows in the list */
        let row = list.querySelectorAll('[data-selected="yes"]');

        /** Loop through the selected added rows */
        for (let i = 0; i < row.length; i++) {

            let strippedID = row[i].id.replace("addedRow_", "");

            /** Remove all removed rows from local state */
            setAddedProductServices(addedProductServices.filter(item => item.id !== strippedID));
            console.log("Line 586")

            /** Remove the selected added row */
            row[i].remove();

            enableProductOptionRows(strippedID);
        }
    }

    /*** END: PRODUCTS / SERVICES FUNCTIONS **/


    /*********************************************************************************** 
     * Form buttons handlers 
     ***********************************************************************************/
    
    /** Navigate Back To Requester Queue */
    const handleReturnToQueue = () => {
        navigate("/");
    }

    /** Validate Form is not blank */
    let formErrors = {
        omniAssetIdError: false,
        ctmTopicError: false,
        pdfError: false,
        pdfHiresError: false,
        assetNameError: false,
        assetDescriptionError: false,
        keywordsError: false,
        lobError: false,
        productsError: false,
        audienceError: false,
        brandDivisionError: false,
        ctmDocumentTypeError: false,
        omniDocumentTypeError: false,
        pharmacyTopicTypeError: false,
        ctmBenefitTypeError: false,
        omniBenefitTypeError: false,
        fundingTypeError: false,
        assetRevisionDateError: false,
        contentSmeNameError: false,
        assetOwnerNameError: false,
        assetOwnerEmailError: false,
        assetOwnerEmailInvalidError: false,
        statesError: false,
        postEnrollmentError: false,
        ctmBusinessUnitError: false,
        omniBusinessUnitError: false,
        languageError: false,
    }
    const validateFormData = (event) => {
        event.preventDefault();

        /** Request ID */ 
        const requestID = Math.floor(1000 + Math.random() * 9000);
        formSystem === "CTM" && dispatch(requestActions.createRequest({key: "id", value: requestID, system: "CTM"}));
        formSystem === "Omni" && dispatch(requestActions.createRequest({key: "id", value: requestID, system: "Omni"}));
        if (formSystem === "Both") {
            dispatch(requestActions.createRequest({key: "id", value: requestID, system: "CTM", type: "Both"}));
            dispatch(requestActions.createRequest({key: "id", value: requestID, system: "Omni", type: "Both"}));
        }

        /** Request Number */
        formSystem === "CTM" && dispatch(requestActions.createRequest({key: "request_number", value: "C-" + requestNum, system: "CTM"}));
        formSystem === "Omni" && dispatch(requestActions.createRequest({key: "request_number", value: "O-" + requestNum, system: "Omni"}));
        if (formSystem === "Both") {
            dispatch(requestActions.createRequest({key: "request_number", value: "C-" + requestNum, system: "CTM", type: "Both"}));
            dispatch(requestActions.createRequest({key: "request_number", value: "O-" + requestNum, system: "Omni", type: "Both"}));
        }

        /** Requester Name */
        formSystem === "CTM" && dispatch(requestActions.createRequest({key: "requester_name", value: userName, system: "CTM"}));
        formSystem === "Omni" && dispatch(requestActions.createRequest({key: "requester_name", value: userName, system: "Omni"}));
        if (formSystem === "Both") {
            dispatch(requestActions.createRequest({key: "requester_name", value: userName, system: "CTM", type: "Both"}));
            dispatch(requestActions.createRequest({key: "requester_name", value: userName, system: "Omni", type: "Both"}));
        }

        /** Requester Email */
        formSystem === "CTM" && dispatch(requestActions.createRequest({key: "requester_email", value: userEmail, system: "CTM"}));
        formSystem === "Omni" && dispatch(requestActions.createRequest({key: "requester_email", value: userEmail, system: "Omni"}));
        if (formSystem === "Both") {
            dispatch(requestActions.createRequest({key: "requester_email", value: userEmail, system: "CTM", type: "Both"}));
            dispatch(requestActions.createRequest({key: "requester_email", value: userEmail, system: "Omni", type: "Both"}));
        }

        /** Status Date */
        formSystem === "CTM" && dispatch(requestActions.createRequest({key: "status_date", value: request_date, system: "CTM"}));
        formSystem === "Omni" && dispatch(requestActions.createRequest({key: "status_date", value: request_date, system: "Omni"}));
        if (formSystem === "Both") {
            dispatch(requestActions.createRequest({key: "status_date", value: request_date, system: "CTM", type: "Both"}));
            dispatch(requestActions.createRequest({key: "status_date", value: request_date, system: "Omni", type: "Both"}));
        }


        /** Omni Asset ID */
        if (formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('omni-asset-id');
            const eleLabel = document.getElementById('omni-asset-id-label');
            const eleError = document.getElementById("omni-asset-id-error");
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.omniAssetIdError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.omniAssetIdError = false;
                formSystem === "Omni" && dispatch(requestActions.createRequest({key: "assetid", value: ele.value, system: "Omni"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({key: "assetid", value: ele.value, system: "Omni", type: "Both"}));
            }
        }

        /** CTM Topic */
        if (formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('ctm-topic');
            const eleLabel = document.getElementById('ctm-topic-label');
            const eleError = document.getElementById("ctm-topic-error");
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.ctmTopicError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.ctmTopicError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "ctm_topic", value: ele.value, system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "ctm_topic", value: ele.value, system: "CTM", type: "Both"}));
            }
        }

        /** PDF */
        if (formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('pdf');
            const eleLabel = document.getElementById('pdf-label');
            const eleError = document.getElementById("pdf-error");
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', 'yes');
                eleError.style.display = "block";
                formErrors.pdfError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', 'no');
                eleError.style.display = "none";
                formErrors.pdfError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "pdf", value: ele.value, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "pdf", value: ele.value, system: "Omni"}));
                if (formSystem === "Both") {
                    formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "pdf", value: ele.value, system: "CTM", type: "Both"}));
                    formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "pdf", value: ele.value, system: "Omni", type: "Both"}));
                }
            }
        }

        /** News Article */
        if (formSystem === "CTM" || formSystem === "Both") {
            if (document.getElementById('newsArticle').checked === true) {
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "news_article", value: "yes", system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "news_article", value: "yes", system: "CTM", type: "Both"}));
            }
            else {
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "news_article", value: "no", system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "news_article", value: "no", system: "CTM", type: "Both"}));
            }
        }

        /** Omni PDF High Resolution */
        if (formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('pdfHires');
            const eleLabel = document.getElementById('pdfHires-label');
            const eleError = document.getElementById("pdfHires-error");
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.pdfHiresError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.pdfHiresError = false;
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "pdf_hires", value: ele.value, system: "Omni"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "pdf_hires", value: ele.value, system: "Omni", type: "Both"}));
            }
        }

        /** UA (Tagged or Untagged) */
        if (formSystem === "Omni" || formSystem === "Both") {
            if (document.getElementById('ua-tagged').checked) {
                formSystem === "Omni" && dispatch(requestActions.createRequest({key: "ua", value: "UA Tagged", system: "Omni"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({key: "ua", value: "UA Tagged", system: "Omni", type: "Both"}));
            }
            else {
                formSystem === "Omni" && dispatch(requestActions.createRequest({key: "ua", value: "UA Untagged", system: "Omni"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({key: "ua", value: "UA Untagged", system: "Omni", type: "Both"}));
            }
        }

        /** Rush */
        if (document.getElementById('rush').checked === true) {
            const comments = document.getElementById('rush-comments').value;
            formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "rush", value: "yes", comments: comments, system: "CTM"}));
            formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "rush", value: "yes", comments: comments, system: "Omni"}));
            if (formSystem === "Both") {
                dispatch(requestActions.createRequest({obj: true, key: "rush", value: "yes", comments: comments, system: "CTM", type: "Both"}));
                dispatch(requestActions.createRequest({obj: true, key: "rush", value: "yes", comments: comments, system: "Omni", type: "Both"}));
            }
        }
        else {
            formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "rush", value: "no", comments: "", system: "CTM"}));
            formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "rush", value: "no", comments: "", system: "Omni"}));
            if (formSystem === "Both") {
                dispatch(requestActions.createRequest({obj: true, key: "rush", value: "no", comments: "", system: "CTM", type: "Both"}));
                dispatch(requestActions.createRequest({obj: true, key: "rush", value: "no", comments: "", system: "Omni", type: "Both"}));
            }
        }

        /** Asset Name */
        if (formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('asset-name');
            const eleLabel = document.getElementById('asset-name-label');
            const eleError = document.getElementById("asset-name-error");
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.assetNameError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.assetNameError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "asset_name", value: ele.value, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "asset_name", value: ele.value, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "asset_name", value: ele.value, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "asset_name", value: ele.value, system: "Omni", type: "Both"}));
                }
            }
        }

        /** Asset Description */
        if (formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('asset-description');
            const eleLabel = document.getElementById('asset-description-label');
            const eleError = document.getElementById('asset-description-error');
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.assetDescriptionError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.assetDescriptionError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "asset_description", value: ele.value, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "asset_description", value: ele.value, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "asset_description", value: ele.value, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "asset_description", value: ele.value, system: "Omni", type: "Both"}));
                }
            }
        }

        /** Keywords */
        if (formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('keywords');
            const eleLabel = document.getElementById('keywords-label');
            const eleError = document.getElementById('keywords-error');
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.keywordsError = true;
            }
            else {
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none"; 
                formErrors.keywordsError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "keywords", value: ele.value, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "keywords", value: ele.value, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "keywords", value: ele.value, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "keywords", value: ele.value, system: "Omni", type: "Both"}));
                }
            }
        }

        /** LOB / Customer Segment */
        if (formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('lob');
            const eleLabel = document.getElementById('lob-label');
            const eleError = document.getElementById('lob-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.lobError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.lobError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "lob_customer_segment", value: lobSelectedOptionIDs, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "lob_customer_segment", value: lobSelectedOptionIDs, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "lob_customer_segment", value: lobSelectedOptionIDs, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "lob_customer_segment", value: lobSelectedOptionIDs, system: "Omni", type: "Both"}));
                }
            }
        }

         /** Products / Services */
         if (formSystem === "CTM" || formSystem === "Both") {
            const eleList = document.getElementById('addedList');
            const ele = document.getElementById('products');
            const eleLabel = document.getElementById('products-label');
            const eleError = document.getElementById('products-error');
            if (!eleList.firstChild) {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.productsError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.productsError = false;

                /** Pull out value and put into an array */
                let products = [];
                addedProductServices.map((product) => {
                    products.push({id: product.id, value: product.value});
                })

                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "products_services", value: products, system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "products_services", value: products, system: "CTM", type: "Both"})); 
            }
        }

        /** Audience */
        if (formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('audience'); 
            const eleLabel = document.getElementById('audience-label');
            const eleError = document.getElementById('audience-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.audienceError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.audienceError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "audience", value: addedAudienceId, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "audience", value: addedAudienceId, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "audience", value: addedAudienceId, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "audience", value: addedAudienceId, system: "Omni", type: "Both"}));
                } 
            }
        }

        /** Brand / Division */
        if (formSystem === "CTM"|| formSystem === "Omni"|| formSystem === "Both") {
            const ele = document.getElementById('brand-division'); 
            const eleLabel = document.getElementById('brand-division-label');
            const eleError = document.getElementById('brand-division-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.brandDivisionError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.brandDivisionError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "brand_division", value: addedBrandDivisionId, system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "brand_division", value: addedBrandDivisionId, system: "CTM", type: "Both"}));
            }
        }

        /** CTM Document Type */
        if (formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('ctm-document-type'); 
            const eleLabel = document.getElementById('ctm-document-type-label');
            const eleError = document.getElementById('ctm-document-type-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.ctmDocumentTypeError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.ctmDocumentTypeError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "ctm_document_type", value: addedCtmDocumentTypeId, system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "ctm_document_type", value: addedCtmDocumentTypeId, system: "CTM", type: "Both"}));
            }
        }

        /** Omni Document Type */
        if (formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('omni-document-type'); 
            const eleLabel = document.getElementById('omni-document-type-label');
            const eleError = document.getElementById('omni-document-type-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.omniDocumentTypeError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.omniDocumentTypeError = false;
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "omni_document_type", value: addedOmniDocumentTypeId, system: "Omni"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "omni_document_type", value: addedOmniDocumentTypeId, system: "Omni", type: "Both"}));  
            }
        }

        /** Pharmacy Topic Type */
        if (formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('pharmacy-topic-type'); 
            const eleLabel = document.getElementById('pharmacy-topic-type-label');
            const eleError = document.getElementById('pharmacy-topic-type-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.pharmacyTopicTypeError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.pharmacyTopicTypeError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "pharmacy_topic_type", value: addedPharmacyTopicTypeId, system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "pharmacy_topic_type", value: addedPharmacyTopicTypeId, system: "CTM", type: "Both"}));
            }
        }

        /** CTM Benefit Type */
        if (formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('ctm-benefit-type'); 
            const eleLabel = document.getElementById('ctm-benefit-type-label');
            const eleError = document.getElementById('ctm-benefit-type-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.ctmBenefitTypeError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.ctmBenefitTypeError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "ctm_benefit_type", value: addedCtmBenefitTypeId, system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "ctm_benefit_type", value: addedCtmBenefitTypeId, system: "CTM", type: "Both"}));
            }
        }

        /** Omni Benefit Type */
        if (formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('omni-benefit-type'); 
            const eleLabel = document.getElementById('omni-benefit-type-label');
            const eleError = document.getElementById('omni-benefit-type-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.omniBenefitTypeError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.omniBenefitTypeError = false;
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "omni_benefit_type", value: addedOmniBenefitTypeId, system: "Omni"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "omni_benefit_type", value: addedOmniBenefitTypeId, system: "Omni", type: "Both"}));
            }
        }

        /** Funding Type */
        if (formSystem === "Omni" || formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('funding-type'); 
            const eleLabel = document.getElementById('funding-type-label');
            const eleError = document.getElementById('funding-type-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.fundingTypeError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.fundingTypeError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "funding_type", value: addedFundingTypeId, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "funding_type", value: addedFundingTypeId, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "funding_type", value: ele.innerHTML, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "funding_type", value: ele.innerHTML, system: "Omni", type: "Both"}));
                } 
            }
        }

        /** Request Date */
        if (formSystem === "Omni" || formSystem === "Both") {
            const requestDate = document.getElementById('request-date').value;
            formSystem === "Omni" && dispatch(requestActions.createRequest({key: "request_date", value: requestDate, system: "Omni"}));
            formSystem === "Both" && dispatch(requestActions.createRequest({key: "request_date", value: requestDate, system: "Omni", type: "Both"}));
        }

        /** Asset Revision Date */
        if (formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('asset-revision-date');
            const eleLabel = document.getElementById('asset-revision-date-label');
            const eleError = document.getElementById('asset-revision-date-error');
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.assetRevisionDateError = true;
            }
            else {
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.assetRevisionDateError = false;
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "asset_revision_date", value: ele.value, system: "Omni"}));
                formSystem === "both" && dispatch(requestActions.createRequest({obj: true, key: "asset_revision_date", value: ele.value, system: "Omni", type: "Both"}));
            }
        }

        /** Last Verified Date */
        if (formSystem === "CTM" || formSystem === "Both") {
            const lastVerifiedDate = document.getElementById('last-verified-date').value;
            formSystem === "CTM" && dispatch(requestActions.createRequest({key: "last_verified_date", value: lastVerifiedDate, system: "CTM"}));
            formSystem === "Both" && dispatch(requestActions.createRequest({key: "last_verified_date", value: lastVerifiedDate, system: "CTM", type: "Both"}));
        }

        /** Content SME Name */
        if (formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('content-sme-name'); 
            const eleLabel = document.getElementById('content-sme-name-label');
            const eleError = document.getElementById('content-sme-name-error');
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.contentSmeNameError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.contentSmeNameError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({key: "content_sme_name", value: ele.value, system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({key: "content_sme_name", value: ele.value, system: "CTM", type: "Both"}));
            }
        }

        /** Asset Owner Name */
        if (formSystem === "Omni" || formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('asset-owner-name'); 
            const eleLabel = document.getElementById('asset-owner-name-label');
            const eleError = document.getElementById('asset-owner-name-error');
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.assetOwnerNameError = true;
            }
            else {
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.assetOwnerNameError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "asset_owner_name", value: ele.value, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "asset_owner_name", value: ele.value, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "asset_owner_name", value: ele.value, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "asset_owner_name", value: ele.value, system: "Omni", type: "Both"}));
                }
            }
        }

        /** Asset Owner Email */
        if (formSystem === "Omni" || formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('asset-owner-email'); 
            const eleLabel = document.getElementById('asset-owner-email-label');
            const eleError = document.getElementById('asset-owner-email-error');
            const eleInvalidError = document.getElementById('asset-owner-email-invalid-error');
            if (ele.value === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.assetOwnerEmailError = true;
            }
            else {
                /** Check if email is valid */
                if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(ele.value)) {
                    eleLabel.setAttribute('invalid', "yes");
                    ele.setAttribute('invalid', "yes");
                    eleInvalidError.style.visibility = "visible";
                    formErrors.assetOwnerEmailInvalidError = false;
                }
                else {
                    eleLabel.setAttribute('error', "no");
                    ele.setAttribute('error', "no");
                    eleLabel.setAttribute('invalid', "no");
                    ele.setAttribute('invalid', "no");
                    eleError.style.display = "none";
                    eleInvalidError.style.visibility = "hidden";
                    formErrors.assetOwnerEmailError = false;
                    formErrors.assetOwnerEmailInvalidError = false;
                    formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "asset_owner_email", value: ele.value, system: "CTM"}));
                    formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "asset_owner_email", value: ele.value, system: "Omni"}));
                    if (formSystem === "Both") {
                        dispatch(requestActions.createRequest({obj: true, key: "asset_owner_email", value: ele.value, system: "CTM", type: "Both"}));
                        dispatch(requestActions.createRequest({obj: true, key: "asset_owner_email", value: ele.value, system: "Omni", type: "Both"}));
                    }
                }
            }
        }

        /** States */
        if (formSystem === "Omni" || formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('states'); 
            const eleLabel = document.getElementById('states-label');
            const eleError = document.getElementById('states-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.statesError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.statesError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "states", value: ele.innerHTML, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "states", value: ele.innerHTML, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "states", value: ele.innerHTML, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "states", value: ele.innerHTML, system: "Omni", type: "Both"}));
                }
            }
        }

        /** Pre or Post Enrollment */
        if (formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('pre-post-enrollment'); 
            const eleLabel = document.getElementById('pre-post-enrollment-label');
            const eleError = document.getElementById('pre-post-enrollment-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.postEnrollmentError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.postEnrollmentError = false;
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "pre_post_enrollment", value: addedPrePostEnrollmentId, system: "Omni"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "pre_post_enrollment", value: addedPrePostEnrollmentId, system: "Omni", type: "Both"})); 
            }
        }

        /** CTM Business Unit */
        if (formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('ctm-business-unit'); 
            const eleLabel = document.getElementById('ctm-business-unit-label');
            const eleError = document.getElementById('ctm-business-unit-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.ctmBusinessUnitError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.ctmBusinessUnitError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "ctm_business_unit", value: addedCtmBusinessUnitId, system: "CTM"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "ctm_business_unit", value: addedCtmBusinessUnitId, system: "CTM", type: "Both"}));
            }
        }

        /** Omni Business Unit */
        if (formSystem === "Omni" || formSystem === "Both") {
            const ele = document.getElementById('omni-business-unit'); 
            const eleLabel = document.getElementById('omni-business-unit-label');
            const eleError = document.getElementById('omni-business-unit-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.omniBusinessUnitError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.omniBusinessUnitError = false;
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "omni_business_unit", value: addedOmniBusinessUnitId, system: "Omni"}));
                formSystem === "Both" && dispatch(requestActions.createRequest({obj: true, key: "omni_business_unit", value: addedOmniBusinessUnitId, system: "Omni", type: "Both"})); 
            }
        }

        /** Language */
        if (formSystem === "Omni" || formSystem === "CTM" || formSystem === "Both") {
            const ele = document.getElementById('language'); 
            const eleLabel = document.getElementById('language-label');
            const eleError = document.getElementById('language-error');
            if (ele.innerHTML === "") {
                eleLabel.setAttribute('error', "yes");
                ele.setAttribute('error', "yes");
                eleError.style.display = "block";
                formErrors.languageError = true;
            }
            else { 
                eleLabel.setAttribute('error', "no");
                ele.setAttribute('error', "no");
                eleError.style.display = "none";
                formErrors.languageError = false;
                formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "language", value: addedLanguageId, system: "CTM"}));
                formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "language", value: addedLanguageId, system: "Omni"}));
                if (formSystem === "Both") {
                    dispatch(requestActions.createRequest({obj: true, key: "language", value: addedLanguageId, system: "CTM", type: "Both"}));
                    dispatch(requestActions.createRequest({obj: true, key: "language", value: addedLanguageId, system: "Omni", type: "Both"}));
                }
            }
        }

        /** Notes */
        const notes = document.getElementById('notes').value;
        formSystem === "CTM" && dispatch(requestActions.createRequest({obj: true, key: "notes", value: notes, system: "CTM"}));
        formSystem === "Omni" && dispatch(requestActions.createRequest({obj: true, key: "notes", value: notes, system: "Omni"}));
        if (formSystem === "Both") {
            dispatch(requestActions.createRequest({obj: true, key: "notes", value: notes, system: "CTM", type: "Both"}));
            dispatch(requestActions.createRequest({obj: true, key: "notes", value: notes, system: "Omni", type: "Both"}));
        }

        checkForErrors();
    }

    const checkForErrors = () => {
        /** CHECK IF THERE ARE ANY ERRORS */
        if (formSystem === "CTM") {
            if (
                formErrors.ctmTopicError === false &&
                formErrors.pdfError === false &&
                formErrors.assetNameError === false &&
                formErrors.assetDescriptionError === false &&
                formErrors.keywordsError === false &&
                formErrors.lobError === false &&
                formErrors.productsError === false &&
                formErrors.audienceError === false &&
                formErrors.brandDivisionError === false &&
                formErrors.ctmDocumentTypeError === false &&
                formErrors.pharmacyTopicTypeError === false &&
                formErrors.ctmBenefitTypeError === false &&
                formErrors.fundingTypeError === false &&
                formErrors.contentSmeNameError === false &&
                formErrors.assetOwnerNameError === false &&
                formErrors.assetOwnerEmailError === false &&
                formErrors.assetOwnerEmailInvalidError === false &&
                formErrors.statesError === false &&
                formErrors.ctmBusinessUnitError === false &&
                formErrors.languageError === false
            ) {
                dispatchFormData("CTM");
            } else {
                let errorElements = document.getElementsByClassName(style["field-error-wrapper"]);
                for (let i = 0; i < errorElements.length; i++) {
                    if (errorElements[i].style.display === "block") {
                        window.scroll(0, errorElements[i].offsetTop - 200);
                        break;
                    }
                }
            }
        }

        if (formSystem === "Omni") {
            if (
                formErrors.omniAssetIdError === false &&
                formErrors.pdfError === false &&
                formErrors.pdfHiresError === false &&
                formErrors.assetNameError === false &&
                formErrors.assetDescriptionError === false &&
                formErrors.keywordsError === false &&
                formErrors.lobError === false &&
                formErrors.audienceError === false &&
                formErrors.brandDivisionError === false &&
                formErrors.omniDocumentTypeError === false &&
                formErrors.omniBenefitTypeError === false &&
                formErrors.fundingTypeError === false &&
                formErrors.assetRevisionDateError === false &&
                formErrors.assetOwnerNameError === false &&
                formErrors.assetOwnerEmailError === false &&
                formErrors.assetOwnerEmailInvalidError === false &&
                formErrors.statesError === false &&
                formErrors.postEnrollmentError === false &&
                formErrors.omniBusinessUnitError === false &&
                formErrors.languageError === false
            ) {
                dispatchFormData("Omni");
            } else {
                let errorElements = document.getElementsByClassName(style["field-error-wrapper"]);
                for (let i = 0; i < errorElements.length; i++) {
                    if (errorElements[i].style.display === "block") {
                        window.scroll(0, errorElements[i].offsetTop - 200);
                        break;
                    }
                }
            }
        }

        if (formSystem === "Both") {
            if (
                formErrors.omniAssetIdError === false &&
                formErrors.ctmTopicError === false &&
                formErrors.pdfError === false &&
                formErrors.pdfHiresError === false &&
                formErrors.assetNameError === false &&
                formErrors.assetDescriptionError === false &&
                formErrors.keywordsError === false &&
                formErrors.lobError === false &&
                formErrors.productsError === false &&
                formErrors.audienceError === false &&
                formErrors.brandDivisionError === false &&
                formErrors.ctmDocumentTypeError === false &&
                formErrors.omniDocumentTypeError === false &&
                formErrors.pharmacyTopicTypeError === false &&
                formErrors.ctmBenefitTypeError === false &&
                formErrors.omniBenefitTypeError === false &&
                formErrors.fundingTypeError === false &&
                formErrors.assetRevisionDateError === false &&
                formErrors.contentSmeNameError === false &&
                formErrors.assetOwnerNameError === false &&
                formErrors.assetOwnerEmailError === false &&
                formErrors.assetOwnerEmailInvalidError === false &&
                formErrors.statesError === false &&
                formErrors.postEnrollmentError === false &&
                formErrors.ctmBusinessUnitError === false &&
                formErrors.omniBusinessUnitError === false &&
                formErrors.languageError === false
            ) {
                dispatchFormData("Both");
            } else {
                let errorElements = document.getElementsByClassName(style["field-error-wrapper"]);
                for (let i = 0; i < errorElements.length; i++) {
                    if (errorElements[i].style.display === "block") {
                        window.scroll(0, errorElements[i].offsetTop - 200);
                        break;
                    }
                }
            }
        }
    }

    const dispatchFormData = (system) => {
        dispatch(requestActions.addRequest(system));
        navigate("/");
    }

    /** Clear form errors */
    const clearError = (labelID, eleID, errorID) => {

        const ele = document.getElementById(eleID);
        const eleLabel = document.getElementById(labelID);
        const eleError = document.getElementById(errorID);
        const eleInvalidError = document.getElementById('asset-owner-email-invalid-error');

        if (eleID === "addedList") {
            document.getElementById(eleID).setAttribute('error', 'no');
            eleLabel.setAttribute('error', "no");
        }
        else if (eleID === "asset-owner-email-error") {
            eleInvalidError.style.display = "none";
        }
        else {
            eleLabel.setAttribute('error', "no");
            ele.setAttribute('error', "no");
            eleError.style.display = "none";
        }
    }

    /** Clear Products/Services error */
    const clearProdError = () => {
        document.getElementById('products-error').style.display = "none";
        document.getElementById('products-label').setAttribute('error', 'no');
        document.getElementById('products').setAttribute('error', 'no');
    }
    

    return (
        <Card style={location.state.action === "Edit" ? {marginTop: "80px"} : {marginTop: "40px"}}>
            <div className={style['form']}>
                <div className={style['reference-number']}>Request to Add Content</div>
                <span className={style['required-label']}>All fields are required unless marked otherwise.</span>

                {/************************************************************************************************ 
                    REQUEST NUMBER 
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <label>Request Number</label><span className={style['small-label']}>(Auto Generated)</span>
                    <input 
                        width="100%"
                        id="request-number" 
                        name="request-number"
                        className={`${style['form-input']}`} 
                        disbaled="disabled" 
                        readOnly={true} 
                        defaultValue={requestNum} 
                    />
                </div>

                {/************************************************************************************************ 
                    CTM TOPIC | SYSTEM: CTM
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="CTM">
                        <label id="ctm-topic-label" error="no">CTM Topic</label>
                        <span className={style['small-label']}>(Limit 20 characters)</span>
                        <input 
                            id="ctm-topic" 
                            name="ctm-topic" 
                            className={style['form-input']} 
                            defaultValue="" 
                            onChange={() => validateValueLength("20", "ctm-topic")}
                            error="no"
                            autoComplete="off"
                            onFocus={() => clearError('ctm-topic-label', 'ctm-topic', 'ctm-topic-error')}
                        />
                        
                        <div id="ctm-topic-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please enter a topic.</span>
                        </div>
                        
                        <div className={style['character-count']}>
                            <span>Total Characters: {!totalCharactersCtmTopic ? "0" : totalCharactersCtmTopic}</span>
                        </div>
                    </div>
                ) : null}
                    

                {/************************************************************************************************ 
                    PDF | SYSTEM: BOTH 
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <label 
                        id="pdf-label" 
                        style={{display: "block", marginBottom: "2px"}}
                        error="no"
                    >
                        PDF
                    </label>
                    <FileUpload 
                        id="pdf"
                        handleFile={handleUploadedFilePdf}
                        error="no"
                        onFocus={() => clearError('pdf-label', 'pdf', 'pdf-error')}
                        onChange={() => clearError('pdf-label', 'pdf', 'pdf-error')}
                    />
                    
                    <div id="pdf-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                        <span className={style["field-error"]}>This is a required field. Please upload a file.</span>
                    </div>

                    {formSystem === "CTM" || formSystem === "Both" ? (
                        <div style={{width: "100%"}} system="CTM">
                            <Checkbox id="newsArticle" label="Relates to News Article" />
                        </div>
                    ) : null}
                </div>


                
                {/************************************************************************************************ 
                    OMNI HIGH RESOLUTION | UA TAGGED & UNTAGGED | SYSTEM: OMNI 
                ************************************************************************************************/}
                {formSystem === "Omni"  || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Omni">
                        <div style={{width: "100%"}}>
                            <label 
                                id="pdfHires-label" 
                                error="no"
                            >
                                    Omni High Resolution (Print) PDF
                            </label>
                        </div>
                        <div style={{width: "100%"}}>
                            <div style={{width: "74%", float: "left"}}>
                                <FileUpload 
                                    id="pdfHires"
                                    handleFile={handleUploadedFileOmniHighResPdf} 
                                    width="100%"
                                    error="no"
                                    onFocus={() => clearError('pdfHires-label', 'pdfHires', 'pdfHires-error')}
                                    onChange={() => clearError('pdfHires-label', 'pdfHires', 'pdfHires-error')}
                                />
                            </div>
                            <div style={{width: "12%", float: "left", marginTop: "10px", marginLeft: "20px"}}>
                                <Radio id="ua-tagged" label="UA Tagged" value="UA Tagged" name="ua" checked="checked" />
                            </div>
                            <div style={{width: "12%", float: "right", marginTop: "10px"}}>
                                <Radio id="ua-untagged" label="UA Untagged" value="UA Untagged" name="ua" />
                            </div>
                        </div>
                        
                        <div id="pdfHires-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please upload a file.</span>
                        </div>
                    </div>
                ) : null}


                {/************************************************************************************************ 
                    RUSH REQUEST | SYSTEM: BOTH
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <Checkbox id="rush" label="Rush" value="" name="" onChange={handleToggleRushComments} error="no" />
                    
                    {openRushComments && (
                        <div style={{width: "100%"}}>
                            <label htmlFor="ra" style={{display: "block", marginBottom: "10px"}} error="no">Rush Comments</label>
                            <textarea 
                                id="rush-comments" 
                                name="rush-comments" 
                                className={style['form-textarea']}
                                style={{marginBottom: "10px"}}
                                error="no"
                                defaultValue=""
                            />
                        </div>
                    )}
                </div>

                {/************************************************************************************************ 
                    OMNI ASSET ID | SYSTEM: OMNI
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Omni">
                        <label id="omni-asset-id-label" error="no">Omni Asset ID</label>
                        <input 
                            id="omni-asset-id" 
                            name="omni-asset-id" 
                            className={style['form-input']} 
                            defaultValue=""
                            onChange={() => validateValueLength("20", "omni-asset-id")}
                            error="no"
                            autoComplete="off"
                            onFocus={() => clearError('omni-asset-id-label', 'omni-asset-id', 'omni-asset-id-error')}
                        />
                        
                        <div id="omni-asset-id-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please enter an ID.</span>
                        </div>
                    </div>
                ) : null}


                {/************************************************************************************************ 
                    ASSET NAME | SYSTEM: BOTH 
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <label id="asset-name-label" error="no">Asset Name</label>
                    <input 
                        id="asset-name"
                        name="asset-name" 
                        className={style['form-input']} 
                        defaultValue=""
                        error="no"
                        autoComplete="off"
                        onFocus={() => clearError('asset-name-label', 'asset-name', 'asset-name-error')} 
                    />

                    <div id="asset-name-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                        <span className={style["field-error"]}>This is a required field. Please enter an asset name.</span>
                    </div>
                </div>


                {/************************************************************************************************ 
                    ASSET DESCRIPTION | SYSTEM: BOTH 
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <label id="asset-description-label" error="no">Asset Description</label>
                    <textarea 
                        id="asset-description" 
                        name="asset-description" 
                        className={style['form-textarea']}
                        error="no"
                        defaultValue=""
                        onFocus={() => clearError('asset-description-label', 'asset-description', 'asset-description-error')}
                    />
                    
                    <div id="asset-description-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                        <span className={style["field-error"]}>This is a required field. Please enter an asset description.</span>
                    </div>
                </div>
                

                {/************************************************************************************************ 
                    KEYWORDS | SYSTEM: BOTH 
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <label id="keywords-label" error="no">Keywords</label><span className={style['small-label']}>(Limit 25 characters)</span>
                    <input
                        id="keywords"
                        name="keywords" 
                        className={style['form-input']} 
                        defaultValue=""
                        onChange={() => validateValueLength("25", "keywords")}
                        error="no"
                        autoComplete="off"
                        onFocus={() => clearError('keywords-label', 'keywords', 'keywords-error')}
                    />

                    <div id="keywords-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                        <span className={style["field-error"]}>This is a required field. Please enter keywords.</span>
                    </div>

                    <div className={style['character-count']}>
                        <span>Total Characters: {!totalCharactersKeywords ? "0" : totalCharactersKeywords}</span>
                    </div>
                </div>


                {/************************************************************************************************ 
                    LOB / CUSTOMER SEGMENT | SYSTEM: BOTH 
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <label id="lob-label" error="no">LOB / Customer Segment</label>
                    <span className={style['small-label']}>(Can select multiple)</span>
                    <SelectMultiple 
                        id="lob"
                        optionId={setAddedLob}
                        options={lobCustomerSegmentOptions} 
                        name="lob" 
                        width="98%" 
                        menuWidth="90.4%" 
                        wide={true} 
                        selectedValues={handleSelectedValuesLob}
                        selectedOptions={lobSelectedOptions}
                        values=""
                        error="no"
                        onFocus={() => clearError('lob-label', 'lob', 'lob-error')}
                    />
                    
                    <div id="lob-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                        <span className={style["field-error"]}>This is a required field. Please select atleast one option.</span>
                    </div>
                </div>


                {/************************************************************************************************ 
                    PRODUCTS & SERVICES | SYSTEM: CTM 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="CTM">
                        <label id="products-label" error="no">Products & Services</label>
                        
                        <div id="products-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select atleast one product or service.</span>
                        </div>

                        <AplhaFilterBar />
                        <div className={style['search-bar']}>
                            <Input width="850px" id="lobForProdServ" name="lob-customer-segment-values" error="" placeholder="Selected LOB / Customer Segment" />
                            <Input width="50%" name="Search" error="" placeholder="Search" />
                            <Button type="outline" size="default" label="Search" />
                        </div>
                        
                        <div className={style['lists-container']}>
                            <div className={style['products-services-list']} error="no">
                                <div className={style["list-outer"]}>
                                    <div id="productList" className={style["list-inner"]}>
                                        {productServicesOptions.map((option) => (
                                            <div 
                                                className={style['list-row']}
                                                key={option.id}
                                                onClick={() => handleProductSelectedRow(option.id, option.name)}
                                                data-selected="no"
                                                data-disabled="no"
                                                data-row="productRow"
                                                id={option.id}
                                                ref={ref => { productRow.current[option.id] = ref; }}
                                            >
                                                <div className={style['product-name']}>{option.name}</div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <div className={style['add-remove-buttons']}>
                                <div className={style["add-button"]}>    
                                    <Button 
                                        id="addButton"
                                        disabled={isAddButtonDisabled}
                                        type="outline" 
                                        size="default" 
                                        label="Add" 
                                        width="120px" 
                                        icon={iconRight} 
                                        position="right"
                                        onClick={() => addProductsServices(addedProductServices)}
                                    />
                                </div>
                                <div>
                                    <Button 
                                        id="removeButton"
                                        disabled={isRemoveButtonDisabled}
                                        type="outline" 
                                        size="default" 
                                        label="Remove" 
                                        width="120px"
                                        icon={iconLeft} 
                                        position="left"
                                        onClick={removeProductsAddedRow}
                                    />
                                </div>
                            </div>

                            <div id="products" className={style['added-products-services-list']} error="no">
                                <div className={style["list-outer"]}>
                                    <div id="addedList" className={style["list-inner"]}></div>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
                

                {/************************************************************************************************ 
                    AUDIENCE | SYSTEM: BOTH 
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <label id="audience-label" error="no">Audience</label>
                    <FormSelect 
                        options={audienceOptions} 
                        defaultValue="" 
                        id="audience"
                        optionId={handleSelectedValuesAudience}
                        name="audience" 
                        width="98%" 
                        menuWidth="90.4%" 
                        wide={true} 
                        error="no"
                        onFocus={() => clearError('audience-label', 'audience', 'audience-error')}
                    />

                    
                    <div id="audience-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                        <span className={style["field-error"]}>This is a required field. Please select an audience.</span>
                    </div>
                </div>

                {/************************************************************************************************ 
                    BRAND / DIVISION | SYSTEM: BOTH 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']}>
                        <label id="brand-division-label" error="no">Brand / Division</label>
                        <FormSelect 
                            options={brandDivisionOptions} 
                            defaultValue="" 
                            id="brand-division"
                            optionId={handleSelectedValuesBrand}
                            name="brand-division" 
                            width="98%" 
                            menuWidth="90.2%" 
                            wide={true}
                            error="no"
                            onFocus={() => clearError('brand-division-label', 'brand-division', 'brand-division-error')}
                        />
                        
                        <div id="brand-division-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select an audience.</span>
                        </div>
                    </div>
                ) : null}
                

                {/************************************************************************************************ 
                    CTM DOCUMENT TYPE | SYSTEM: CTM
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="CTM">
                        <label id="ctm-document-type-label" error="no">CTM Document Type</label>
                        <FormSelect 
                            options={ctmDocumentTypeOptions} 
                            defaultValue="" 
                            id="ctm-document-type"
                            optionId={handleSelectedValuesCtmDocumentType}
                            name="ctm-document-type" 
                            width="98%" 
                            menuWidth="90.2%" 
                            wide={true}
                            error="no"
                            onFocus={() => clearError('ctm-document-type-label', 'ctm-document-type', 'ctm-document-type-error')} 
                        />

                        <div id="ctm-document-type-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a document type.</span>
                        </div>
                    </div>
                ) : null}
                

                {/************************************************************************************************ 
                    OMNI DOCUMENT TYPE | SYSTEM: OMNI 
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Omni">
                        <label id="omni-document-type-label" error="no">Omni Document Type</label>
                        <FormSelect 
                            options={omniDocumentTypeOptions} 
                            defaultValue=""
                            id="omni-document-type"
                            optionId={handleSelectedValuesOmniDocumentType}
                            name="omni-document-type" 
                            width="98%" 
                            menuWidth="90.2%" 
                            wide={true}
                            error="no"
                            onFocus={() => clearError('omni-document-type-label', 'omni-document-type', 'omni-document-type-error')} 
                        />
                        
                        <div id="omni-document-type-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a document type.</span>
                        </div>
                    </div>
                ) : null}
                

                {/************************************************************************************************ 
                    PHARMACY TOPIC TYPE | SYSTEM: CTM 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="CTM">
                        <label id="pharmacy-topic-type-label" >Pharmacy Topic Type</label><span className={style['small-label']}>(Optional)</span>
                        <FormSelect 
                            options={pharmacyTopicTypeOptions} 
                            defaultValue="" 
                            id="pharmacy-topic-type"
                            optionId={handleSelectedValuesPharmacyDocumentType}
                            name="pharmacy-topic-type" 
                            width="98%" 
                            menuWidth="90.4%" 
                            wide={true}
                            onFocus={() => clearError('pharmacy-topic-type-label', 'pharmacy-topic-type', 'pharmacy-topic-type-error')} 
                        />
                        
                        <div id="pharmacy-topic-type-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a document type.</span>
                        </div>
                    </div>
                ) : null}
                
                
                {/************************************************************************************************ 
                    CTM BENEFIT TYPE | SYSTEM: CTM 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="CTM">
                        <label id="ctm-benefit-type-label" error="no">CTM Benefit Type</label>
                        <FormSelect 
                            options={ctmBenefitTypeOptions} 
                            defaultValue=""
                            id="ctm-benefit-type"
                            optionId={handleSelectedValuesCtmBenefitType} 
                            name="ctm-benefit-type" 
                            width="98%" 
                            menuWidth="90.4%" 
                            wide={true}
                            error="no"
                            onFocus={() => clearError('ctm-benefit-type-label', 'ctm-benefit-type', 'ctm-benefit-type-error')} 
                        />
                        
                        <div id="ctm-benefit-type-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a benefit type.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    OMNI BENEFIT TYPE | SYSTEM: OMNI 
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Omni">
                        <label id="omni-benefit-type-label" error="no">Omni Benefit Type</label>
                        <FormSelect 
                            options={omniBenefitTypeOptions} 
                            defaultValue=""
                            id="omni-benefit-type"
                            optionId={handleSelectedValuesOmniBenefitType}
                            name="omni-benefit-type" 
                            width="98%" 
                            menuWidth="90.4%" 
                            wide={true}
                            error="no"
                            onFocus={() => clearError('omni-benefit-type-label', 'omni-benefit-type', 'omni-benefit-type-error')} 
                        />
                        
                        <div id="omni-benefit-type-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a benefit type.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    FUNDING TYPE | SYSTEM: BOTH 
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "CTM" || formSystem === "Both" ? ( 
                    <div className={style['form-control']} system="Both">
                        <label id="funding-type-label" error="no">Funding Type</label>
                        <FormSelect 
                            options={fundingTypeOptions} 
                            defaultValue=""
                            id="funding-type"
                            optionId={handleSelectedValuesFundingType} 
                            name="funding-type" 
                            width="98%" 
                            menuWidth="90.4%" 
                            wide={true}
                            error="no"
                            onFocus={() => clearError('funding-type-label', 'funding-type', 'funding-type-error')} 
                        />
                        
                        <div id="funding-type-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a benefit type.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    REQUEST DATE | SYSTEM: OMNI
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Omni">
                        <label>Request Date</label><span className={style['small-label']}>(Auto Generated)</span>
                        <input 
                            id="request-date" 
                            className={style['form-input']} 
                            name="request-date" 
                            error="error"
                            defaultValue={request_date} 
                            disabled 
                        />
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    ASSET REVISION DATE | SYSTEM: OMNI 
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Omni">
                        <label id="asset-revision-date-label" error="no">Asset Revision Date</label>
                        <DatePicker 
                            id="asset-revision-date" 
                            width="100%" 
                            name="asset-revision-date" 
                            error="error" 
                            defaultValue=""
                            onClick={triggerDateOpen}
                            onFocus={() => clearError('asset-revision-date-label', 'asset-revision-date', 'asset-revision-date-error')} 
                        />
                        
                        <div id="asset-revision-date-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a benefit type.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    LAST VERIFIED DATE | SYSTEM: CTM 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="CTM">
                        <label>Last Verified Date</label><span className={style['small-label']}>(Auto Generated)</span>
                        <input 
                            id="last-verified-date"
                            name="last-verified-date"
                            className={style['form-input']}
                            defaultValue={last_Verified_Date}
                            disabled
                        />
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    CONTENT SME NAME | SYSTEM: CTM 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="CTM">
                        <label id="content-sme-name-label" error="no">Content SME Name</label><span className={style['small-label']}></span>
                        <input 
                            width="100%"
                            id="content-sme-name" 
                            name="content-sme-name"
                            className={style['form-input']}
                            defaultValue=""
                            error="no"
                            autoComplete="off"
                            onFocus={() => clearError('content-sme-name-label', 'content-sme-name', 'content-sme-name-error')}
                            onKeyPress={(event) => validateNames(event)} 
                        />
                        
                        <div id="content-sme-name-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please enter a name.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    REQUESTER NAME | SYSTEM: BOTH 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both" ? (    
                    <div className={style['form-control']} system="Both">
                        <label>Requester Name</label><span className={style['small-label']}>(Auto Filled)</span>
                        <input 
                            id="requester-name"
                            type="text"
                            width="100%" 
                            name="requester-name" 
                            className={`${style['form-input']}`} 
                            defaultValue={userName}
                            disabled
                        />
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    REQUESTER EMAIL | SYSTEM: BOTH 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Both">
                        <label>Requester Email</label><span className={style['small-label']}>(Auto Filled)</span>
                        <input 
                            id="requester-email"
                            type="email" 
                            width="100%" 
                            name="requester-email" 
                            className={style['form-input']} 
                            defaultValue={userEmail}
                            disabled
                        />
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    ASSET OWNER NAME | SYSTEM: BOTH 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Both">
                        <label id="asset-owner-name-label" error="no">Asset Owner Name</label>
                        <input 
                            id="asset-owner-name"
                            name="asset-owner-name"
                            type="text" 
                            className={style['form-input']} 
                            defaultValue=""
                            error="no"
                            autoComplete="off"
                            onFocus={() => clearError('asset-owner-name-label', 'asset-owner-name', 'asset-owner-name-error')}
                            onKeyPress={(event) => validateNames(event)} 
                        />
                        
                        <div id="asset-owner-name-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please enter a name.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    ASSET OWNER EMAIL | SYSTEM: BOTH 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Both">
                        <label 
                            id="asset-owner-email-label"
                            invaild="no" 
                            error="no"
                        >
                            Asset Owner Email
                        </label>
                        <input 
                            type="email"
                            id="asset-owner-email"
                            name="asset-owner-email"
                            className={style['form-input']} 
                            defaultValue=""
                            error="no"
                            invaild="no"
                            autoComplete="off"
                            onFocus={() => clearError('asset-owner-email-label', 'asset-owner-email', 'asset-owner-email-error')} 
                        />

                        
                        <div id="asset-owner-email-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please enter a email address.</span>
                        </div>
                        
                        <div id="asset-owner-email-invalid-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>Please enter a valid email address.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    STATES | SYSTEM: BOTH 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Both">
                        <label id="states-label" error="no">States</label>
                        <SelectStates 
                            id="states"
                            name="states" 
                            width="98%" 
                            menuWidth="90.4%" 
                            wide={true} 
                            selectedOptions={handleStateOptions}
                            selectedStates={stateSelectedOptions}
                            values=""
                            error="no"
                            onFocus={() => clearError('states-label', 'states', 'states-error')} 
                        />
                        
                        <div id="states-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select atleast one state.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    PRE OR POST ENROLLMENT PIECE | SYSTEM: OMNI 
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Omni">
                        <label id="pre-post-enrollment-label" error="no">Pre or Post Enrollment Piece</label>
                        <FormSelect 
                            options={prePostEnrollmentOptions} 
                            defaultValue=""
                            id="pre-post-enrollment"
                            optionId={handleSelectedValuesPrePostEnrollment} 
                            name="pre-post-enrollment" 
                            width="98%" 
                            menuWidth="90.4%"
                            wide={true}
                            error="no" 
                            onFocus={() => clearError('pre-post-enrollment-label', 'pre-post-enrollment', 'pre-post-enrollment-error')} 
                        />

                        <div id="pre-post-enrollment-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select an option.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    CTM BUSINESS UNIT | SYSTEM: CTM 
                ************************************************************************************************/}
                {formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="CTM">
                        <label id="ctm-business-unit-label" error="no">CTM Business Unit</label>
                        <FormSelect 
                            options={ctmBusinessUnitOptions} 
                            defaultValue=""
                            id="ctm-business-unit"
                            optionId={handleSelectedValuesCtmBusinessUnit}
                            name="ctm-business-unit" 
                            width="98%" 
                            menuWidth="90.4%" 
                            wide={true} 
                            error="no"
                            onFocus={() => clearError('ctm-business-unit-label', 'ctm-business-unit', 'ctm-business-unit-error')} 
                        />
                        
                        <div id="ctm-business-unit-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a business unit.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    OMNI BUSSINESS UNIT | SYSTEM: OMNI 
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Omni">
                        <label id="omni-business-unit-label" error="no">Omni Business Unit</label>
                        <FormSelect
                            options={omniBusinessUnitOptions} 
                            defaultValue="" 
                            id="omni-business-unit"
                            optionId={setAddedOmniBusinessUnitId}
                            name="omni-business-unit" 
                            width="98%" 
                            menuWidth="90.4%" 
                            wide={true}
                            error="no"
                            onFocus={() => clearError('omni-business-unit-label', 'omni-business-unit', 'omni-business-unit-error')} 
                        />
                        
                        <div id="omni-business-unit-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a business unit.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    LANGUAGE | SYSTEM: BOTH 
                ************************************************************************************************/}
                {formSystem === "Omni" || formSystem === "CTM" || formSystem === "Both" ? (
                    <div className={style['form-control']} system="Both">
                        <label id="language-label" error="no">Language</label>
                        <FormSelect 
                            options={languageOptions} 
                            defaultValue="" 
                            id="language"
                            optionId={handleSelectedValuesLanguage}
                            name="language" 
                            width="98%" 
                            menuWidth="90.4%"
                            menuHeight="100px" 
                            wide={true}
                            error="no"
                            onFocus={() => clearError('language-label', 'language', 'language-error')} 
                        />
                        
                        <div id="language-error" className={style["field-error-wrapper"]} style={{display: "none"}}>
                            <span className={style["field-error"]}>This is a required field. Please select a language.</span>
                        </div>
                    </div>
                ) : null}

                {/************************************************************************************************ 
                    NOTES | SYSTEM: OMNI 
                ************************************************************************************************/}
                <div className={style['form-control']} system="Both">
                    <label>Notes</label><span className={style['small-label']}>(Optional)</span>
                    <textarea 
                        id="notes" 
                        name="notes"
                        className={`${style['form-textarea']}`}
                        defaultValue=""
                    />
                </div>



                {/************************************************************************************************ 
                    ACTION BUTTONS (RETUR TO QUEUE / SUBMIT) 
                ************************************************************************************************/}
                <div className={style['form-control']}>
                    <div style={{width: "100%", display: "flex", gap: "20px"}}>
                        <Button type="outline" size="default" label="Return to Request Queue" onClick={handleReturnToQueue} />
                        <Button type="solid" size="default" label="Submit" onClick={validateFormData} />
                    </div>
                </div>
            </div>
        </Card>
    )
}