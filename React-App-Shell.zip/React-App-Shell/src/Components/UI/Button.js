import React from "react";
import styles from './Button.module.css';

/** HOW TO USE 
 * 
 * Type: Solid, Outline
 * Size: Default, Small, Wide (100%)
 * Position: Right (Floats button to the right)
 * Width: Overides the default width
 * Disabled: disabled / you don't need to set a value
*/
const Button = (props) => {

    let width;
    if (props.width) {
        width = props.width;
    }

    let display = "";
    if (!props.icon) {
        display = <div className={styles["label"]}>{props.label}</div>
    } else if (props.icon && props.position === "right") {
        display = <div className={styles["display-wrapper-right"]}>
                    <div className={styles["label"]}>{props.label}</div>
                    <img src={props.icon} alt="" />
                  </div>
    } else if (props.icon && props.position === "left") {
        display = <div className={styles["display-wrapper-left"]}>
                    <img src={props.icon} alt="" />
                    <div className={styles["label"]}>{props.label}</div>
                </div>
    }

    let disabledClass;
    if (props.type === 'solid' && props.disabled) {
        disabledClass = 'solid-disabled';
    }

    if (props.type === 'outline' && props.disabled) {
        disabledClass = 'outline-disabled';
    }


    return (
      <button type={props.usage} id="Button" onClick={props.onClick} style={{width: width}} className={`
            ${styles['button']} 
            ${styles[props.type]} 
            ${styles[props.size]}
            ${styles[props.position]}
            ${styles[disabledClass]}
        `}>
            {display}  
        </button>
    );
};

export default Button;