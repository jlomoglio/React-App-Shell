import React, { Fragment } from "react";
import styled from 'styled-components';

const InputText = styled.input`
    font: inherit;
    color: #5a5a5a;
    padding: 10px;
    border-radius: 6px;
    border: 1px solid ${(props) => props.flagged === "yes" ? "red;" : "#ccc;" }
    width: ${props => props.width};
    height: 22px;
    font-size: 15px;
    font-size: 15px;

    &:focus::-webkit-input-placeholder {
        color: transparent;
    }

    &:focus {
        outline: none;
    }
`

export default function Input(props) {
    const onChangeHandler = () => { return props.onChange(props.value)}

    return (
        <Fragment>
            <InputText 
                id={props.id} 
                type={props.type ? props.type : "text"} 
                name={props.name} 
                value={props.value} 
                placeholder={props.placeholder}
                width={props.width}
                flagged={props.flagged}
                readOnly={props.readOnly}
                onChange={onChangeHandler}
            />
        </Fragment>
    )
}