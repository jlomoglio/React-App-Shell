import React from "react";
import styled from 'styled-components';
//import styles from './Button.module.css';

/** HOW TO USE 
 * 
 * Type: Solid, Outline
 * Size: Default, Small, Wide (100%)
 * Position: Right (Floats button to the right)
 * Width: Overides the default width
 * Disabled: disabled / you don't need to set a value
*/

const StyledButton = styled.button`
    border-radius: 5px;
    cursor: pointer;
    box-shadow: 0 2px 2px rgba(0, 0, 0, 0.15);
    display: flex;
    align-content: center;
    padding-top: 13px;
    text-align: center;

    /** Outline */
    border: 1px solid #ccc;
    background-color: #fff;
    color: #5A5A5A;

    /** Solid */
    border: 1px solid  #002676;
    background-color:  #002676;
    color: #fff;


    /** Default */
    width: auto;
    height: 42px;
    padding-left: 20px;
    padding-right: 20px;
    font-size: 14px;

    /** Small */
    width: auto;
    height: 36px;
    padding-left: 12px;
    padding-right: 8px;
    font-size: 14px;
    margin-bottom: 8px;
    padding-top: 10px;
    text-align: center;

    /** Wide */
    width: 100%;
    height: 42px;
    font-size: 14px;
    padding-left: 20px;
    padding-right: 20px;



    /** Left */
    margin-top: 0;
    margin-left: 0;
    margin-right: auto;
    margin-bottom: 0;

    /** Right */
    margin-top: 0;
    margin-left: auto;
    margin-right: 0;
    margin-bottom: 0;


`

const Img = styled.img`
    width: 12px;
    height: 12px;
    margin: 5px;
    margin-top: 2px; 
`

const DisplayWrapper = styled.div`

`

const Label = styled.div`

`


const Button = (props) => {

    let width;
    if (props.width) {
        width = props.width;
    }

    let display = "";
    if (!props.icon) {
        display = <div className={styles["label"]}>{props.label}</div>
    } else if (props.icon && props.position === "right") {
        display = <div className={styles["display-wrapper-right"]}>
                    <div className={styles["label"]}>{props.label}</div>
                    <img src={props.icon} alt="" />
                  </div>
    } else if (props.icon && props.position === "left") {
        display = <div className={styles["display-wrapper-left"]}>
                    <img src={props.icon} alt="" />
                    <div className={styles["label"]}>{props.label}</div>
                </div>
    }

    let disabledClass;
    if (props.type === 'solid' && props.disabled) {
        disabledClass = 'solid-disabled';
    }

    if (props.type === 'outline' && props.disabled) {
        disabledClass = 'outline-disabled';
    }


    return (
      <button id="Button" onClick={props.onClick} style={{width: width}} className={`
            ${styles['button']} 
            ${styles[props.type]} 
            ${styles[props.size]}
            ${styles[props.position]}
            ${styles[disabledClass]}
        `}>
            {display}  
        </button>
    );
};

export default Button;