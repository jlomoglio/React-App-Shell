import React, { Fragment, useState, useEffect } from "react";
import styled from "styled-components";
import checkmark from '../Icons/checkmark.png';

const StyledCheckbox = styled.div`
    width: 20px;
    height: 20px;
    border-radius: 3px;
    border: 2px solid ${props => props.color }
    cursor: pointer;
    background-color: ${props => props.checked ? props.color :'#fff;' }
    display: flex;
`

const Checkmark = styled.img`
    width: 14px;
    height: 14px;
    padding-top: 3px;
    padding-left: 3px;
    padding-right: 5px;
    padding-bottom: 5px;
    cursor: pointer;
`

const Label = styled.div`
    height: 14px;
    line-height: 18px;
    margin-left: 10px;
    color: ${props => props.color}
    cursor: default;
`

export default function Checkbox(props) {

    const [color, setColor] = useState();
    const [checked, setChecked] = useState(false);

    /** Set Status Colors */
    useEffect(() => {
        if (props.status === 'All' ) { setColor('#000;'); }
        else if (props.status === 'Submitted' ) { setColor('#EB6200;'); }
        else if (props.status === 'Flagged' ) { setColor('#DA1E28;'); }
        else if (props.status === 'Approved' ) { setColor('#2AD000;'); }
        else if (props.status === 'Untagged' ) { setColor('#F5B700;'); }
        else if (props.status === 'Completed' ) { setColor('#008CFF;'); }
        else if (props.status === 'Canceled' ) { setColor('#6e7072;'); }
    }, [props.status])

    /** Check / Uncheck Checkbox */
    const toggleCheckmark = () => {
        setChecked(!checked)
    }

    return (
      <StyledCheckbox color={color} checked={checked}>
        <Checkmark src={checkmark} onClick={toggleCheckmark}/> 
        <Label color={color}>{props.status}</Label>
      </StyledCheckbox>  
    )
}