import React, { useState } from "react";
import styled from "styled-components";
import checkmark from '../Icons/checkmark.png';

/** HOW TO USE 
 * 
 * ID, Name, Label, Value
 * Disabled: disabled / NEED TO ADD THIS
*/

const Wrapper = styled.div`
    display: flex;
    height: 30px;
    min-width: 50px;
    margin-left: 6px;
`

const StyledCheckbox = styled.input`
    width: 24px;
    height: 24px;
    border-radius: 5%;
    outline: none;
    appearance: none;
    -webkit-appearance: none;
    vertical-align: middle;
    background-color: #fff;
    border: 2px solid #ccc !important;
    cursor: ${(props) => props.disabled ? "default;" : "pointer;"}
    display: none;

    &+ label {
        display:inline-block;
        padding: 0 0 0 0px;
        height: 20px;
        width: 20px;
        background-size: 20px;
        border-radius: 10%;
        border: 2px solid ${(props) => props.flagged === "yes" || props.error === "yes" ? "red;" : "#ccc !important;"}
        cursor: ${(props) => props.active === "false" ? "default;" : "pointer;"}
        color: #5a5a5a;
        background-color: #fff;
    }

    &:checked + label {
        background: url(${checkmark}) no-repeat;
        background-color: ${(props) => props.active === "false" ? "#ccc;" : props.flagged === "yes" || props.error === "yes" ? "red;" : "#008CFF !important;"}
        height: 20px;
        width: 20px;
        display: inline-block;
        background-size: 70% 70%;
        background-position: center;
        border-radius: 10%;
        border: 2px solid ${(props) => props.active === "false" ? "#ccc;" : props.flagged === "yes" || props.error === "yes" ? "red;" : "#008CFF !important;"}
        cursor: ${(props) => props.active === "false" ? "default;" : "pointer;"}
    }
`

const Custom = styled.label``

const Label = styled.div`
    height: 14px;
    min-width: 50px;
    line-height: 24px;
    margin-left: 12px;
    color: ${(props) => props.flagged === "yes" || props.error === "yes" ? "red;" : "#5a5a5a;"}
    cursor: default;
    font-weight: 600;
`

export default function Checkbox(props) {

    return (
        <Wrapper>
            <StyledCheckbox 
                id={props.id} 
                type="checkbox" 
                name={props.name} 
                value={props.defaultValue} 
                onChange={props.onChange}
                flagged={props.flagged}
                error={props.error}
                checked={props.checked}
                active={props.active}
            />
            <Custom htmlFor={props.id} />
            <Label htmlFor={props.id} flagged={props.flagged}>{props.label}</Label>
        </Wrapper>  
    )
}