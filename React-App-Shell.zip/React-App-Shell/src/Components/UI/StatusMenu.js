import React, { Fragment, useEffect, useState, useRef } from "react";
import styles from '../UI/StatusMenu.module.css';
import downChevron from '../../Components/Icons/down-arrow.png';
import StatusCheckbox from "./StatusCheckbox";

/** 
 * Hook to close the menu when user clicks outside of it.
 * Keeping it here so there is no dependency on it, when using
 * this component in other projects. 
 * */
let useClickOutside = (handler) => {
    let domNode = useRef();

    useEffect(() => {
        let mayBeHandler = (event) => {
            if (!domNode.current?.contains(event.target)) {
                handler();
            }
        }
    
        document.addEventListener('mousedown', mayBeHandler);
    
        return () => {
            document.removeEventListener("mousedown", mayBeHandler);
        }
    });

    return domNode;
}


export default function StatusMenu(props) {

    const [open, setOpen] = useState(false);
    /**
     * Opens the menu
     */
     const handleOpen = () => {
        setOpen(!open);
    };

    /**
     * Gets the selected options
     */
    const handleSelected = () => {

    }
    
    let domNode = useClickOutside(() => {
        setOpen(false);
    });

    return (
        <div className={styles['status-box-wrapper']} ref={domNode}>
            <div className={status['status-box']} onClick={handleOpen}>
                <span>Status</span>
                <img className={styles['down-chevron']} src={downChevron} alt="" />
            </div>
            {open ? (
                <div id="statusMenu" className={styles['status-menu']}>
                    <div className={styles['row']}>
                        <StatusCheckbox status="All" selected={handleSelected} />
                    </div>
                    <div className={styles['row']}>
                        <StatusCheckbox status="Submitted" />
                    </div>
                    <div className={styles['row']}>
                        <StatusCheckbox status="Flagged" />
                    </div>
                    <div className={styles['row']}>
                        <StatusCheckbox status="Approved" />
                    </div>
                    <div className={styles['row']}>
                        <StatusCheckbox status="Untagged" />
                    </div>
                    <div className={styles['row']}>
                        <StatusCheckbox status="Completed" />
                    </div>
                    <div className={styles['row']}>
                        <StatusCheckbox status="Canceled" />
                    </div>
                </div>
            ) : null}
        </div> 
    )
}