import React, { useState, useEffect, useRef } from "react";
import styled from 'styled-components';

/** 
 * Hook to close the menu when user clicks outside of it.
 * Keeping it here so there is no dependency on it, when using
 * this component in other projects. 
 * */
let useClickOutside = (handler) => {
    let domNode = useRef();

    useEffect(() => {
        let mayBeHandler = (event) => {
            if (!domNode.current?.contains(event.target)) {
                handler();
            }
        }
    
        document.addEventListener('mousedown', mayBeHandler);
    
        return () => {
            document.removeEventListener("mousedown", mayBeHandler);
        }
    });

    return domNode;
}

/**
 * USAGE: Props
 * 
 *  name: Used to display in the select box.
 *  options: Array of data for the dropdown menu.
 *  data: Used when component needs to pass selected value back to parent.
 *  width: Overrides the dynamic width. (Optional)
 */

const DomNode = styled.div`
    display: ${props => props.wide ? "block" : null};
    width: ${props => props.wide ? "100%;" : null};
`

const StyledSelect = styled.div`
    height: 36px;
    padding-left: 10px;
    padding-right: 15px;
    padding-top: 3px;
    padding-bottom: 3px;
    line-height: 36px;
    border: 1px solid ${(props) => props.flagged === 'yes' || props.error === 'yes' ? "red;" : "#ccc;"}
    border-radius: 5px;
    background-color: ${(props) => props.active === "false" ? "#fafafa;" : "#fff;"}
    font-size: 15px;
    cursor: ${(props) => props.active === "false" ? "default;" : "pointer;"}
    position: relative;
    -webkit-user-select: none;
    -ms-user-select: none;
    user-select: none;
    display: inline-block;
    color: ${(props) => props.flagged === 'yes' || props.error === 'yes' ? "red;" : "#5a5a5a;"}
    font-size: 15px;
    width: max-content;

    &.value {
        margin-right: 30px;
    }

    &:after {
        content: '';
        position: absolute;
        top: 20px;
        right: 10px;
        border-top: 5px solid #000;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
    }
`

const StyledListContainer = styled.div`
    height: 200px;
    border: 1px solid ${(props) => props.flagged === 'yes' || props.error === 'yes' ? "red;" : "#ccc;"}
    border-radius: 8px;
    box-shadow: 0 2px 2px rgba(0, 0, 0, 0.15);
    z-index: 1000 !important;
    position: absolute;
    background-color: #fff;
    margin-top: 2px;
    perspective: 1px;
    margin-top: -1px;
`
const StyledListBody = styled.div`
    padding: 8px;
    width: auto;
`

const StyledListOuter = styled.div`
    padding-bottom: 15px;
    height: 200px;
`

const StyledListInner = styled.div`
    overflow-y: scroll;
    overflow-x: hidden;
    height: 180px;
    width: 100%;

    &::-webkit-scrollbar {
        width: 15px;
    }

    &::-webkit-scrollbar-track {
        background-color: #f0efef;
        border-radius: 100vw;
        margin-block: 5px;
    }

    &::-webkit-scrollbar-thumb {
        background-color: #ccc;
        border-radius: 100vw;
    }

    &::-webkit-scrollbar-thumb:hover {
        background-color: rgb(122, 120, 120);
    }
`

const StyledMenu = styled.div`
    margin: 2px 0;
    border-radius: 5px;
    perspective: 1px;
    min-width: 60px;
    max-height: 180px;
    margin-right: 180px;
    width: 90%;
`

const StyledMenuItem = styled.div `
    list-style-type: none;
    width: 97.5%;
    height: 20px;
    margin: 0px;
    padding-left: 15px;
    padding-right: 10px;    
    padding-top: 12px;
    padding-bottom: 8px;
    background-color: #fff;
    font-size: 14px;
    cursor: pointer;
    -webkit-user-select: none; /* Safari */
    -ms-user-select: none; /* IE 10 and IE 11 */
    user-select: none; /* Standard syntax */
    border: 1px solid #fff;
    border-radius: 6px;
    color: #5a5a5a;

    &:hover {
        background-color: #F4F4F4;
    }

    &.menu-item-selected: background-color: rgba(182, 207, 243, 0.805);
`


const Select = React.forwardRef((props,ref) => {
    /** 
     * STATE VARIABLES 
     * */
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState();

    const selectBoxRef = useRef();

    /** Add stored values */
    useEffect(() => {
        if (props.defaultValue.length > 0) {
            setValue(props.defaultValue);  
        }
    }, [props.defaultValue])
    
    /**
     * Opens the menu
     */
    const handleOpen = () => {
        setOpen(!open);
    };

    /**
     * Closes the menu and set the value.
     */
    const handleValue = (event) => {
        /** Updates state in parent if set */
        if (props.data) {
            props.data(event.target.getAttribute('data-value'))
        };

        /** Sets the displayed value in the select */
        setValue(event.target.getAttribute('data-value'));

        /** Close the menu */
        handleOpen(!open);
    };

    /** Make sure that state is updated immediately for filters */
    useEffect(() => {}, [value]);
    useEffect(() => {}, [open]);

    /**
     * Create width of selectBox based on widest menu-item. 
     * Get the length of the longest string and then multiply by 8 (there are 8px in a charatcer) 
     * the add 35px for additional padding.
     * */
     let nameWidth = props.name.length * 8 + 35;
     let width = Math.max(...(props.options.map(el => el.length)));
     let newWidth;

     if (props.width) {
         newWidth = props.width;
     }
     else if (width > nameWidth) {
         newWidth = nameWidth; 
     } else {
         newWidth = width * 8 + 35;
     } 

    let domNode = useClickOutside(() => {
        setOpen(false);
    });

    return (
        <DomNode ref={domNode} wide={props.wide}>
            {/** SELECT DROPDOWN */}
            <StyledSelect 
                ref={selectBoxRef} 
                tabIndex="1" 
                id={props.id} 
                onClick={props.active === "false" ? null : handleOpen} 
                style={{width: newWidth, marginBottom: "3px"}}
                flagged={props.flagged}
                error={props.error}
                defaultValue={props.defaultValue}
                onFocus={props.onFocus}
                active={props.active}
            >
               {value}
            </StyledSelect>

            {/** SELECT DROPDOWN MENU */}
            {open ? (
                <StyledListContainer
                    style={props.menuHeight ? {width: props.menuWidth, height: props.menuHeight} : {width: props.menuWidth}}
                    flagged={props.flagged}
                    error={props.error}
                >
                    <StyledListBody>
                        <StyledListOuter>
                            <StyledListInner 
                                id="list-inner" 
                                style={props.menuHeight ? {overflowY: "hidden"} : {overflowY: "scroll"}}
                            >

                                <StyledMenu 
                                    style={
                                        props.menuHeight && props.menuWidth < 225 + "px" ? {width: "97%"} : {width: "100%"}
                                    }
                                >
                                    {props.options.map((option, index) => (
                                        <StyledMenuItem
                                            key={index} 
                                            onClick={handleValue}
                                            data-value={option}
                                            style={props.menuHeight === "100px" ? {width: "98.5%"} : props.menuHeight && {width: "89.5%"}}
                                        >
                                            {option}
                                        </StyledMenuItem>
                                    ))}
                                </StyledMenu>

                            </StyledListInner>
                        </StyledListOuter>
                    </StyledListBody>
                </StyledListContainer>                
            ) : null}
        </DomNode>
    );
})

export default Select;