import React, { useEffect, useRef } from "react";
import styled from 'styled-components';

/**
 * STYLED COMPONENTS
 */
const StyledButton = styled.div`
    width: 40px;
    height: 40px;
    padding: 2px;
    font-size: 14px;
    text-align: center;
    line-height: 24px;
    border: 1px solid ${(props) => props.style === 'solid' ? '#002676;' : '#ccc;'}
    border-radius: 4px;
    background-color:  ${(props) => props.style === 'solid' ? '#002676;' : '#fff;'}
    color: ${(props) => props.style === 'solid'  ? '#fff;' : '#5A5A5A;'}
    box-shadow: 0 2px 2px rgba(0, 0, 0, 0.15);
    cursor: pointer;
    -webkit-user-select: none;
    -ms-user-select: none;
    user-select: none;

    &:hover {
        background-color: ${(props) => props.style === 'outline' && 'rgb(183, 202, 241, .2);'}
    }
`

export default function PaginationBar() {
    const btn = useRef([]);

    const pagBarClass = {
        width: '100%',
        padding: '0',
        display: 'flex',
        gap: '10px'
    }

    const outlineClass = {
        width: '40px',
        height: '30px',
        paddingBottom: '2px',
        paddingTop: '8px',
        paddingleft: '4px',
        paddingright: '4px',
        fontSize: '14px',
        textAlign: 'center',
        lineHeight: '24px',
        border: '1px solid  #ccc',
        borderRadius: '4px',
        backgroundColor: '#fff',
        color: '#5A5A5A',
        boxShadow: '0 2px 2px rgba(0, 0, 0, 0.15)',
        cursor: 'pointer',
    }

    /** 
     * Button Labels 
     * */
    const AZ = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];

    /** 
     * Handles button click for loading the previous data page 
     * */
    const handleClickPrev = () => {
        /** 
         * ADD CODE TO HANDE PREVIOUS PAGE HERE 
         * */
    };

    /** 
     * Handles button click for loading the previous data page 
     * */
    const handleClickFirstPage = () => {
        /** 
         * ADD CODE TO HANDE PREVIOUS PAGE HERE 
         * */
    };

    /** 
     * Handles button click for each data page 
     * */
    let classes = outlineClass;
    const handleClick = (id) => {
         
        /** Loop through the number of pages and set buttons class to default */
        [...Array(numberOfPages)].map((elementInArray, index) => {
            return document.getElementById("btn-" + (index + 1)).setAttribute('style', outlineClass);
        });

        /** Set selected button type to solid */
        document.getElementById(id).style.setProperty('background-color', '#002676');
        document.getElementById(id).style.setProperty('color', '#fff');
        document.getElementById(id).style.setProperty('cursor', 'default');

        /** 
         * ADD FUNCTIONALITY TO LOAD DATE PAGE HERE
         * */

    }

    const btnHover = (e) => {
        if (e.currentTarget.style.cursor !== 'default') {
            e.currentTarget.style.backgroundColor = 'rgb(183, 202, 241, .2)'
        }
    }

    const btnHoverReset = (e) => {
        if (e.currentTarget.style.backgroundColor !== 'rgb(0, 38, 118)') {
            e.currentTarget.style.backgroundColor = '#fff'
        }
    }

    return (
        <div style={pagBarClass}>
            {AZ.map((elementInArray, index) => ( 
                <StyledButton 
                    key={index}
                    id={"btn-" + elementInArray} 
                    style={outlineClass}
                    ref={ref => {btn.current["btn-" + elementInArray] = ref}}
                    onClick={() => handleClick("btn-" + elementInArray)}
                    onMouseEnter={btnHover}
                    onMouseLeave={btnHoverReset}
                >
                    {elementInArray}
                </StyledButton>
            ))}
        </div>
    );
};