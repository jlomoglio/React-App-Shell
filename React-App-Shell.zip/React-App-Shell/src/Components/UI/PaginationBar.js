import React, { useEffect, useRef } from "react";
import styled from 'styled-components';
import LeftDoubleChevron from "../Icons/left-double-chevron.png";
import RightDoubleChevron from "../Icons/right-double-chevron.png";
import LeftChevron from "../Icons/left-chevron.png";

/**
 * STYLED COMPONENTS
 */
const Button = styled.div`
    width: 24px;
    height: 24px;
    padding: 2px;
    font-size: 14px;
    text-align: center;
    line-height: 24px;
    border: 1px solid ${(props) => props.style === 'solid' ? '#002676;' : '#ccc;'}
    border-radius: 4px;
    background-color:  ${(props) => props.style === 'solid' ? '#002676;' : '#fff;'}
    color: ${(props) => props.style === 'solid'  ? '#fff;' : '#5A5A5A;'}
    box-shadow: 0 2px 2px rgba(0, 0, 0, 0.15);
    cursor: pointer;
    -webkit-user-select: none;
    -ms-user-select: none;
    user-select: none;

    &:hover {
        background-color: ${(props) => props.style === 'outline' && 'rgb(183, 202, 241, .2);'}
    }
`

const Img = styled.img`
    width: 12px;
    height: 12px;
    margin-top: 6px;
    transform: ${(props) => props.icon === 'right-chevron' && 'rotate(-180deg);'}
`

export default function PaginationBar() {
    const btn = useRef([]);

    const pagBarClass = {
        width: 'auto',
        padding: '20px',
        display: 'flex',
        gap: '10px',
        float: 'right',
    }

    const outlineClass = {
        width: '24px',
        height: '24px',
        padding: '2px',
        fontSize: '14px',
        textAlign: 'center',
        lineHeight: '24px',
        border: '1px solid  #ccc',
        borderRadius: '4px',
        backgroundColor: '#fff',
        color: '#5A5A5A',
        boxShadow: '0 2px 2px rgba(0, 0, 0, 0.15)',
        cursor: 'pointer',
    }

    const imgClass = {
        width: '12px',
        height: '12px',
        marginTop: '6px',
    }

    const imgRightClass = {
        width: '12px',
        height: '12px',
        marginTop: '6px',
        transform: 'rotate(-180deg)',
    }

    /** 
     * HARD CODED TEMP VALUE
     * Change this to code to handle getting the number of data pages being returned 
     * */
    const numberOfPages = 8;

    /** 
     * Handles button click for loading the previous data page 
     * */
    const handleClickPrev = () => {
        /** 
         * ADD CODE TO HANDE PREVIOUS PAGE HERE 
         * */
    };

    /** 
     * Handles button click for loading the previous data page 
     * */
    const handleClickFirstPage = () => {
        /** 
         * ADD CODE TO HANDE PREVIOUS PAGE HERE 
         * */
    };

    /** 
     * Handles button click for each data page 
     * */
    let classes = outlineClass;
    const handleClick = (id) => {
         
        /** Loop through the number of pages and set buttons class to default */
        [...Array(numberOfPages)].map((elementInArray, index) => {
            return document.getElementById("btn-" + (index + 1)).setAttribute('style', outlineClass);
        });

        /** Set selected button type to solid */
        document.getElementById(id).style.setProperty('background-color', '#002676');
        document.getElementById(id).style.setProperty('color', '#fff');
        document.getElementById(id).style.setProperty('cursor', 'default');

        /** 
         * ADD FUNCTIONALITY TO LOAD DATE PAGE HERE
         * */

    }

    /** 
     * Handles button click for loading the next data page 
     * */
    const handleClickNext = () => {
        /** 
         * ADD CODE TO HANDE NEXT PAGE 
         * */
    };

     /** 
      * Handles button click for loading the previous data page 
      * */
     const handleClickLastPage = () => {
        /** 
         * ADD CODE TO HANDE PREVIOUS PAGE HERE 
         * */
    };

    const btnHover = (e) => {
        if (e.currentTarget.style.cursor !== 'default') {
            e.currentTarget.style.backgroundColor = 'rgb(183, 202, 241, .2)'
        }
    }

    const btnHoverReset = (e) => {
        if (e.currentTarget.style.backgroundColor !== 'rgb(0, 38, 118)') {
            e.currentTarget.style.backgroundColor = '#fff'
        }
    }

    return (
        <div style={pagBarClass}>
            {/** PREVIOUS PAGE BUTTONS */}
            <div 
                id="prevDbl" 
                style={outlineClass} 
                onClick={handleClickFirstPage}
                onMouseEnter={btnHover}
                onMouseLeave={btnHoverReset}
            >
                <Img src={LeftDoubleChevron} icon='chevron' alt="" />
            </div>
            <div 
                id="prev" 
                style={outlineClass} 
                onClick={handleClickPrev}
                onMouseEnter={btnHover}
                onMouseLeave={btnHoverReset}
            >
                <Img src={LeftChevron} icon='left-chevron' alt="" />
            </div>

            {/** PAGE BUTTONS */}
            {[...Array(numberOfPages)].map((elementInArray, index) => ( 
                <Button 
                    key={Math.random()}
                    id={"btn-" + (index + 1)} 
                    style={outlineClass}
                    ref={ref => {btn.current["btn-" + (index + 1)] = ref}}
                    onClick={() => handleClick("btn-" + (index + 1))}
                    onMouseEnter={btnHover}
                    onMouseLeave={btnHoverReset}
                >
                    {index + 1}
                </Button>
            ))}

            {/** NEXT PAGE BUTTONS */}
            <div 
                id="next" 
                style={outlineClass}
                onClick={handleClickNext}
                onMouseEnter={btnHover}
                onMouseLeave={btnHoverReset} 
            >
                <Img src={LeftChevron} icon='right-chevron' alt="" />
            </div>
            <div 
                id="nextDbl" 
                style={outlineClass} 
                onClick={handleClickLastPage}
                onMouseEnter={btnHover}
                onMouseLeave={btnHoverReset}
            >
                <Img src={RightDoubleChevron} icon='chevron' alt="" />
            </div>
        </div>
    );
};