import React from "react";
import styled from 'styled-components';

const InputDate = styled.input`
    font: inherit;
    color: #5a5a5a;
    padding: 10px;
    border-radius: 6px;
    border: 1px solid ${(props) => props.flagged ===  "yes" || props.error === "yes" ? "red;" : "#ccc;"}
    width: ${props => props.width};
    height: 22px;
    font-size: 15px;
    cursor: ${(props) => props.onClick ? "pointer;" : "default;" || props.disabled === true ? "default" : "pointer"}

    &:focus::-webkit-input-placeholder {
        color: transparent;
    }

    &:focus {
        outline: none;
    }

    &[disabled="yes"] {
        cursor: "default";
    }
`

export default function DatePicker(props) {
    return (
        <InputDate 
            id={props.id} 
            type="date"
            name={props.name} 
            defaultValue={props.defaultValue} 
            placeholder={props.placeholder}
            width={props.width}
            error={props.error}
            flagged={props.flagged}
            disabled={props.disabled}
            onClick={props.onClick}
            onFocus={props.onFocus}
        />
    )
}