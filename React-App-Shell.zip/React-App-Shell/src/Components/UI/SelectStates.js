import React, { useState, useEffect, useRef } from "react";
import styled from 'styled-components';

/** 
 * Hook to close the menu when user clicks outside of it.
 * Keeping it here so there is no dependency on it, when using
 * this component in other projects. 
 * */
 let useClickOutside = (handler) => {
    let domNode = useRef();

    useEffect(() => {
        let mayBeHandler = (event) => {
            if (!domNode.current?.contains(event.target)) {
                handler();
            }
        }
    
        document.addEventListener('mousedown', mayBeHandler);
    
        return () => {
            document.removeEventListener("mousedown", mayBeHandler);
        }
    });

    return domNode;
}

/**
 * COMPONENT STYLES
 */

 const DomNode = styled.div`
    display: ${props => props.wide ? "block" : null};
    width: ${props => props.wide ? "100%;" : null};
`

 const StyledSelect = styled.div`
    height: 36px;
    padding-left: 10px;
    padding-right: 15px;
    padding-top: 3px;
    padding-bottom: 3px;
    line-height: 36px;
    border: 1px solid ${(props) => props.flagged === "yes" ? "red;" : "#ccc;"}
    border-radius: 5px;
    background-color: ${(props) => props.active === "false" ? "#fafafa;" : "#fff;"}
    font-size: 15px;
    cursor: ${(props) => props.active === "false" ? "default;" : "pointer;"}
    position: relative;
    -webkit-user-select: none;
    -ms-user-select: none;
    user-select: none;
    display: inline-block;
    color: ${(props) => props.flagged === "yes" ? "red;" : "#5a5a5a;"}
    font-size: 15px;
    width: 90%;

    &.value {
        margin-right: 30px;
    }

    &:after {
        content: '';
        position: absolute;
        top: 20px;
        right: 10px;
        border-top: 5px solid #000;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
    }
`

const StyledListContainer = styled.div`
    height: 200px;
    border: 1px solid ${(props) => props.flagged === "yes" ? "red;" : "#ccc;"}
    border-radius: 8px;
    margin-top: 0px !important;
    box-shadow: 0 2px 2px rgba(0, 0, 0, 0.15);
    z-index: 1000 !important;
    position: absolute;
    background-color: #fff;
    perspective: 1px;
`
const StyledListBody = styled.div`
    padding: 8px;
    width: auto;
`

const StyledListOuter = styled.div`
    padding-bottom: 15px;
    height: 200px;
`

const StyledListInner = styled.div`
    overflow-y: scroll;
    overflow-x: hidden;
    height: 180px;

    &::-webkit-scrollbar {
        width: 15px;
    }

    &::-webkit-scrollbar-track {
        background-color: #f0efef;
        border-radius: 100vw;
        margin-block: 5px;
    }

    &::-webkit-scrollbar-thumb {
        background-color: #ccc;
        border-radius: 100vw;
    }

    &::-webkit-scrollbar-thumb:hover {
        background-color: rgb(122, 120, 120);
    }
`

const StyledMenu = styled.div`
    margin: 0 0 0 0;
    border-radius: 5px;
    perspective: 1px;
    ${'' /* width: ${props.style}; */}
    min-width: 60px;
    max-height: 200px;
    margin-right: 20px;
    width: 96.5%;
`

const StyledMenuItem = styled.div`
    list-style-type: none;
    width: 90%;
    height: 20px;
    margin: 0;
    padding-left: 15px;
    padding-right: 20px;    
    padding-top: 12px;
    padding-bottom: 8px;
    background-color: #fff;
    font-size: 14px;
    cursor: pointer;
    -webkit-user-select: none; /* Safari */
    -ms-user-select: none; /* IE 10 and IE 11 */
    user-select: none; /* Standard syntax */
    border: 1px solid #fff;
    border-radius: 6px;
    color: #5a5a5a;

    &:hover {
        background-color: #F4F4F4;
    }

    &.menu-item-selected: {
        background-color: rgba(182, 207, 243, 0.805);
    }
`


/**
 * USAGE: Props
 * 
 *  options: Array of data for the dropdown menu.
 *  selectedValues(): Used when component needs to pass selected value back to parent.
 *  width: Overrides the dynamic width. (Optional)
 */
const SelectMultiple = React.forwardRef((props, ref) => {

    const STATES = {
        AL: "Alabama",
        AK: "Alaska",
        AZ: "Arizona",
        AR: "Arkansas",
        CA: "California",
        CO: "Colorado",
        CT: "Connecticut",
        DE: "Delaware",
        FL: "Florida",
        GA: "Georgia",
        HI: "Hawaii",
        ID: "Idaho",
        IL: "Illinois",
        IN: "Indiana",
        IA: "Iowa",
        KS: "Kansas",
        KY: "Kentucky",
        LA: "Louisiana",
        ME: "Maine",
        MD: "Maryland",
        MA: "Massachusetts",
        MI: "Michigan",
        MN: "Minnesota",
        MS: "Mississippi",
        MO: "Missouri",
        MT: "Montana",
        NE: "Nebraska",
        NV: "Nevada",
        NH: "New Hampshire",
        NJ: "New Jersey",
        NM: "New Mexico",
        NY: "New York",
        NC: "North Carolina",
        ND: "North Dakota",
        OH: "Ohio",
        OK: "Oklahoma",
        OR: "Oregon",
        PA: "Pennsylvania",
        RI: "Rhode Island",
        SC: "South Carolina",
        SD: "South Dakota",
        TN: "Tennessee",
        TX: "Texas",
        UT: "Utah",
        VT: "Vermont",
        VA: "Virginia",
        WA: "Washington",
        WV: "West Virginia",
        WI: "Wisconsin",
        WY: "Wyoming",
    }


    /** 
     * STATE VARIABLES 
     * */
    const [open, setOpen] = useState(false);
    const [values, setValues] = useState(props.selectedStates);
    const [displayValues, setDisplayValues] = useState([]);
    const [selectedStates, setSelectedStates] = useState([]);

    const selectMultipleBoxRef = useRef();

    /** Add stored vlaues */
    useEffect(() => {
        if (props.values.length > 0) {
            props.values.map((option) => {
                setDisplayValues(displayValues => [...displayValues, option]);
                setValues(values => [...values, option]);
            })
        }
    }, [props.values])

    /**
     * Opens the menu
     */
    const handleOpen = () => {
        setOpen(!open);
        if (open === true) {
            document.getElementById('list-container').style.marginTop = "4px";
        }
    };


    /**
     * Set the values.
     */
    const handleValue = (id, stateName) => {

        const menuItem = document.getElementById(id);
        const menuItemSelected = menuItem.getAttribute('data-selected');

        if (menuItemSelected === 'no') {
            
            menuItem.setAttribute('data-selected', 'yes')
            menuItem.style.backgroundColor = 'rgba(182, 207, 243, 0.805)';
            setSelectedStates(selectedStates => [
                ...selectedStates,
                { name: stateName, selected: "yes"},
            ])

            /** Adds item to state value array */
            setValues(values => [...values, menuItem.getAttribute('data-value')]);

            const stateKey = Object.keys(STATES).find((key) => STATES[key] === stateName);
            setDisplayValues(displayValues => [...displayValues, stateKey])
            
        }
        else if (menuItemSelected === 'yes') {
            menuItem.setAttribute('data-selected', 'no')
            menuItem.style.backgroundColor = '#fff';

            setValues(current => current.filter(state => { return state !== stateName}))

            /** Removes item from displayValues array */
            const stateKey = Object.keys(STATES).find((key) => STATES[key] === stateName);
            setDisplayValues(displayValues.filter(current => current !== stateKey));
        }
    }; 
    

    /** Make sure that state is updated immediately */
    useEffect(() => {}, [open]);
    
    useEffect(() => {
        props.selectedOptions(values);
    },[props.selectedOptions, values])

    /** Adds space after comma for displayed items */
    let displayValuesFormated = displayValues.toString().split(',').join(', ');
    
    /** Handles closing the menu when clicked outside */
    let domNode = useClickOutside(() => {
        setOpen(false);

    });

    return (
        <DomNode ref={domNode} wide={props.wide}>
            <StyledSelect
                ref={selectMultipleBoxRef} 
                tabIndex="1" 
                id={props.id} 
                onClick={props.active === "false" ? null : handleOpen} 
                style={displayValues.length > 0 ? {width: props.width, marginBottom: "3px"} : {width: props.width}}
                flagged={props.flagged}
                error={props.error === 'yes' ? {borderColor: "red"} : {borderColor: "#ccc"}}
                onFocus={props.onFocus}
                active={props.active}
            >
               {displayValues.length > 0 && displayValuesFormated}
            </StyledSelect>

            {open && (           
                <StyledListContainer id="list-container" style={{width: props.menuWidth}} flagged={props.flagged} error={props.error}>
                    <StyledListBody>
                        <StyledListOuter>
                            <StyledListInner>
                                
                                <StyledMenu>
                                    {Object.entries(STATES).map(([stateKey, stateName], index) => {
                                        
                                        let classes = {width: "100%", marginRight: '50px'}
                                        let isSelected = "no"

                                        if (displayValues.length > 0) {
                                            displayValues.map((selectedState) => {
                                                
                                                if(selectedState === stateKey) { 
                                                    classes = {
                                                        width: "100%", 
                                                        marginRight: '50px', 
                                                        backgroundColor: 'rgba(182, 207, 243, 0.805)'
                                                    }
                                                    isSelected = 'yes'
                                                }
                                            })
                                        }
                                                
                                        return (
                                            <StyledMenuItem 
                                                key={index} 
                                                onClick={() => handleValue("menuItem" + index, stateName)}
                                                data-value={stateName}
                                                id={"menuItem" + index}
                                                data-selected={isSelected}
                                                style={classes}
                                            >
                                                {stateName}
                                            </StyledMenuItem>
                                        )
                                    })}
                                    
                                </StyledMenu>

                            </StyledListInner>
                        </StyledListOuter>
                    </StyledListBody>
                </StyledListContainer>
            )}
        </DomNode>
    );
})

export default SelectMultiple;