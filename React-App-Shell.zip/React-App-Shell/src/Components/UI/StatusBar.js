import React, { Fragment } from "react";
import styled from 'styled-components';

const Bar = styled.div`
    width: 115px;
    height: 22px;
    background-color: ${(props) => 
        props.status === 'Submitted' && '#EB6200' ||
        props.status === 'Flagged' && '#DA1E28' ||
        props.status === 'Approved' && '#2AD000' ||
        props.status === 'Completed' && '#008CFF' ||
        props.status === 'Untagged' && '#F5B700' ||
        props.status === 'Canceled' && '#5A5A5A'
    };
    border-radius: 4px;
    margin-top: 8px;
    margin-right: 8px;
    margin-left: -3px;
`

const BarLabel = styled.div`
    font-size: 12px;
    font-weight: 600;
    color: #fff;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 22px;
    
`

export default function RequesterDataTable(props) {


    return (
        <Fragment>
            <Bar status={props.status}>
                <BarLabel>{props.status}</BarLabel>    
            </Bar>
        </Fragment>
    )
}