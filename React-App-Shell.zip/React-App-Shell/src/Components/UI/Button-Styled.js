import React from "react";
import styled from 'styled-components';

/** HOW TO USE 
 * 
 * Type: Solid, Outline
 * Size: Default, Small, Wide (100%)
 * Position: Right (Floats button to the right)
 * Width: Overides the default width
 * Label: Text to be placed on button
 * Icon:
 *   In parent component import leftArrowsIcon from "../../UI/left-double-chevron.png";
 *   porps: icon={leftArrowsIcon}
*/

/**
 * STYLES
 */
const StyledButton = styled.button`
        border-radius: 5px;
        cursor: pointer;
        border-width: .01rem;
        border-style: solid;
        box-shadow: 0 2px 2px rgba(0, 0, 0, 0.15);
        display: flex;
        align-content: center;
        justify-content: center;
        text-align: center;
        margin-bottom: ${(props) => props.size === 'small' && '8;'}

        border-color: ${(props) => 
             props.type === 'solid' && !props.disabled ? '#002676;' : 'rgba(0, 0, 0, 0.15);' ||
             props.type === 'outline' && !props.disabled ? '#ccc' : 'rgba(0, 0, 0, 0.15);'
        }

        background-color: ${(props) => 
             props.type === 'solid' && !props.disabled ? '#002676;' : '#000;' ||
             props.type === 'outline' && !props.disabled ? '#000;' : '#000;' ||
             props.type === 'outline' && props.disabled ? '#000;' : '#000;'
        }
        
        color: ${(props) => 
            props.type === 'solid' && !props.disabled ? '#fff;' : 'rgba(0, 0, 0, 0.15);' ||
            props.type === 'outline' && !props.disabled ? '#5a5a5a;' : 'rgba(0, 0, 0, 0.15);' 
        }

        /** Size (Default, Small, Wide) */
        width: ${(props) =>
            props.size === 'default' && 'auto;' ||
            props.size === 'small' && 'auto;' ||
            props.size === 'wide' && '100%;'
        }

        height: ${(props) =>
            props.size === 'default' && '42px;' ||
            props.size === 'small' && '36px;' ||
            props.size === 'wide' && '42px;'
        }

        padding-top: ${(props) => 
            props.size === 'default' && '13px;' ||
            props.size === 'small' && '10px;' ||
            props.size === 'wide' && '13px;'
        }

        padding-left: ${(props) =>
            props.size === 'default' && '20px;' ||
            props.size === 'small' && '12px;' ||
            props.size === 'wide' && '20px;'
        }
        padding-right: ${(props) =>
            props.size === 'default' && '20px;' ||
            props.size === 'small' && '14px;' ||
            props.size === 'wide' && '20px;'
        }
        
        font-size: 14px;

        cursor: ${(props) => props.disabled ? 'default;' : 'pointer;'}

            &:hover {
                background-color: ${(props) => props.type === 'outline' && 'rgb(183, 202, 241, .2;'}
            }
            
            &.right {
                margin-top: 0;
                margin-left: auto;
                margin-right: 0;
                margin-bottom: 0;
            }
            
            &.left {
                margin-top: 0;
                margin-left: 0;
                margin-right: auto;
                margin-bottom: 0;
            }
            
            &.button img {
                width: 12px;
                height: 12px;
                margin: 5px;
                margin-top: 2px;
            }
            
            &.display-wrapper-left > .label {
                margin-bottom: 4px;
                padding-left: 10px;
            }
            
            &.display-wrapper-right > .label {
                margin-bottom: 4px;
                padding-left: 10px;
                padding-right: 10px;
            }
            
            &.display-wrapper-left > img {
                margin-right: 0;
                margin-left: 0;
            }
            
            &.small > .label {
                margin-bottom: 8px;
                padding-top: auto;
                padding-bottom: 8px;
            }
            
            &.display-wrapper-left {
                display: flex;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: -webkit-box;
                align-content: center;
                text-align: center;
                margin: auto;
                padding-right: 15px;
                padding-bottom: 6px;
            }
            
            &.display-wrapper-right {
                display: flex;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: -webkit-box;
                align-content: center;
                text-align: center;
                margin: auto;
                padding-bottom: 6px;
            }
            
            $.disabled:hover {
                background-color: #fff;
            }
`;

const Button = (props) => {

    let width;
    if (props.width) {
        width = props.width;
    }

    let display = "";
    if (!props.icon) {
        
        display = <div className="label">{props.label}</div>

    } else if (props.icon && props.position === "right") {
        
        display = <div className="display-wrapper-right">
                    <div className="label">{props.label}</div>
                    <img src={props.icon} alt="" />
                  </div>

    } else if (props.icon && props.position === "left") {
        
        display = <div className="display-wrapper-left">
                    <img src={props.icon} alt="" />
                    <div className="label">{props.label}</div>
                </div>
    }

    return (
        <StyledButton 
            type={props.type} 
            size={props.size} 
            onClick={props.onClick} 
            style={{width: width}}
            disabled={props.disabled}
            position={props.position}
        >
            {display}
        </StyledButton>
    );
};

export default Button;