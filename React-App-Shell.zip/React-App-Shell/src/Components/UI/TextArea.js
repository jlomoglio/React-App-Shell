import React, { Fragment, useState, useRef } from "react";
import styled from 'styled-components';

const InputTextArea = styled.textarea`
    font: inherit;
    color: ${(props) => props.flagged === "yes" ? "red;" : "#5a5a5a;"}
    padding: 10px;
    border-radius: 6px;
    border: ${(props) => props.flagged === "yes" ? "1px dashed red;" : "1px solid #ccc;"}
    min-width: 98.5%;
    max-width: 98.5%;
    height: ${props => props.rows + ";"}
    font-size: 15px !important;

    &:focus::-webkit-input-placeholder {
        color: transparent;
    }

    &:focus {
        outline: none;
    }
`

export default function TextArea(props) {
    return (
        <Fragment>
            <InputTextArea 
                id={props.id} 
                type="textarea"
                name={props.name}
                placeholder={props.placeholder}
                flagged={props.flagged} 
                rows={props.height}
                readOnly={props.readOnly}
                value={props.value}
            >
                
            </InputTextArea>
        </Fragment>
    )
}