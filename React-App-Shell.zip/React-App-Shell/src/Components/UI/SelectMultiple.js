import React, { useState, useEffect, useRef } from "react";
import styled from 'styled-components';

/** 
 * Hook to close the menu when user clicks outside of it.
 * Keeping it here so there is no dependency on it, when using
 * this component in other projects. 
 * */
 let useClickOutside = (handler) => {
    let domNode = useRef();

    useEffect(() => {
        let mayBeHandler = (event) => {
            if (!domNode.current?.contains(event.target)) {
                handler();
            }
        }
    
        document.addEventListener('mousedown', mayBeHandler);
    
        return () => {
            document.removeEventListener("mousedown", mayBeHandler);
        }
    });

    return domNode;
}

/**
 * COMPONENT STYLES
 */

 const DomNode = styled.div`
    display: ${props => props.wide ? "block" : null};
    width: ${props => props.wide ? "100%;" : null};
`

 const StyledSelect = styled.div`
    height: 36px;
    padding-left: 10px;
    padding-right: 15px;
    padding-top: 3px;
    padding-bottom: 3px;
    line-height: 36px;
    border: 1px solid ${(props) => props.flagged === "yes" || props.error === "yes" ? "red;" : "#ccc;"}
    border-radius: 5px;
    background-color: ${(props) => props.active === "false" ? "#fafafa;" : "#fff;"}
    font-size: 15px;
    cursor: ${(props) => props.active === "false" ? "default;" : "pointer;"}
    position: relative;
    -webkit-user-select: none;
    -ms-user-select: none;
    user-select: none;
    display: inline-block;
    color: ${(props) => props.flagged === "yes" || props.error === "yes" ? "red;" : "#5a5a5a;"}
    font-size: 15px;
    width: 90%;

    &.value {
        margin-right: 30px;
    }

    &:after {
        content: '';
        position: absolute;
        top: 20px;
        right: 10px;
        border-top: 5px solid #000;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
    }
`

const StyledListContainer = styled.div`
    height: 200px;
    border: 1px solid ${(props) => props.flagged === "yes" || props.error === "yes" ? "red;" : "#ccc;"}
    border-radius: 8px;
    margin-top: 0px !important;
    box-shadow: 0 2px 2px rgba(0, 0, 0, 0.15);
    z-index: 1000 !important;
    position: absolute;
    background-color: #fff;
    perspective: 1px;
`
const StyledListBody = styled.div`
    padding: 8px;
    width: auto;
`

const StyledListOuter = styled.div`
    padding-bottom: 15px;
    height: 200px;
`

const StyledListInner = styled.div`
    overflow-y: scroll;
    overflow-x: hidden;
    height: 180px;

    &::-webkit-scrollbar {
        width: 15px;
    }

    &::-webkit-scrollbar-track {
        background-color: #f0efef;
        border-radius: 100vw;
        margin-block: 5px;
    }

    &::-webkit-scrollbar-thumb {
        background-color: #ccc;
        border-radius: 100vw;
    }

    &::-webkit-scrollbar-thumb:hover {
        background-color: rgb(122, 120, 120);
    }
`

const StyledMenu = styled.div`
    margin: 2px 0;
    border-radius: 5px;
    perspective: 1px;
    min-width: 60px;
    max-height: 180px;
    margin-right: 180px;
    width: 100%;

`

const StyledMenuItem = styled.div`
    list-style-type: none;
    width: 100%;
    height: 20px;
    margin: 0px;
    padding-left: 15px;
    padding-right: 20px;    
    padding-top: 12px;
    padding-bottom: 8px;
    background-color: #fff;
    font-size: 14px;
    cursor: pointer;
    -webkit-user-select: none; /* Safari */
    -ms-user-select: none; /* IE 10 and IE 11 */
    user-select: none; /* Standard syntax */
    border: 1px solid #fff;
    border-radius: 6px;
    color: #5a5a5a;

    &:hover {
        background-color: #F4F4F4;
    }

    &.menu-item-selected: { background-color: rgba(182, 207, 243, 0.805); }
`


/**
 * USAGE: Props
 * 
 *  options: Array of data for the dropdown menu.
 *  selectedValues(): Used when component needs to pass selected value back to parent.
 *  width: Overrides the dynamic width. (Optional)
 */
const SelectMultiple = React.forwardRef((props, ref) => {
    /** 
     * STATE VARIABLES 
     * */
    const [open, setOpen] = useState(false);
    const [values, setValues] = useState(props.selectedOptions);
    const [displayValues, setDisplayValues] = useState([]);
    const [displayIds, setDisplayIds] = useState([]);

    const selectMultipleBoxRef = useRef();

    /** Add stored vlaues */
    useEffect(() => {
        if (props.values.length > 0) {
            props.values.map((option) => {
                setDisplayValues(displayValues => [...displayValues, option.name]);
                setValues(values => [...values, option.name]);
                setDisplayIds(displayIds => [...displayIds, option.id]);
            })
        }
    }, [props.values])

    /**
     * Opens the menu
     */
    const handleOpen = () => {
        setOpen(!open);
    };

    /**
     * Set the values.
     */
    const handleValue = (eleId) => {

        const menuItem = document.getElementById(eleId);
        const menuItemSelected = menuItem.getAttribute('data-selected');

        if (menuItemSelected === 'no') {
            menuItem.setAttribute('data-selected', 'yes')
            menuItem.style.backgroundColor = 'rgba(182, 207, 243, 0.805)';
            document.getElementById(props.id).style.marginBottom = "2px";

            /** Adds item to state value array */
            setValues(values => [...values, menuItem.getAttribute('data-value')]);
            setDisplayValues(displayValues => [...displayValues, menuItem.getAttribute('data-value')]);
            setDisplayIds(displayIds => [...displayIds, menuItem.getAttribute('data-id')]);
        }
        else if (menuItemSelected === 'yes') {
            menuItem.setAttribute('data-selected', 'no')
            menuItem.style.backgroundColor = '#fff';
            document.getElementById(props.id).style.marginBottom = "-2px";
            
            /** Removes item */
            setValues(current =>
                current.filter(option => {
                    return option !== menuItem.getAttribute('data-value')
                }
            ))

            /** Removes item */
            setDisplayValues(current =>
                current.filter(displayValues => {
                    return displayValues !== menuItem.getAttribute('data-value')
                }
            ))

            /** Removes item */
            setDisplayIds(current =>
                current.filter(displayIds => {
                    return displayIds !== menuItem.getAttribute('data-id')
                }
            ))
        }
    };

    /** Make sure that state is updated immediately */
    useEffect(() => {}, [open]);
    
    useEffect(() => {
        props.selectedValues(values, displayIds);
    },[props.selectedValues, values, displayIds])

    /** Adds space after comma for displayed items */
    let displayValuesFormated = displayValues.toString().split(',').join(', ');
    
    /** Handles closing the menu when clicked outside */
    let domNode = useClickOutside(() => {
        setOpen(false);
    });

    return (
        <DomNode ref={domNode} wide={props.wide}>
            <StyledSelect 
                ref={selectMultipleBoxRef} 
                tabIndex="1" 
                id={props.id}
                onClick={props.active === "false" ? null : handleOpen} 
                style={displayValues.length > 0 ? {width: props.width, marginBottom: "3px"} : {width: props.width}}
                flagged={props.flagged}
                error={props.error}
                onFocus={props.onFocus}
                active={props.active}
            >
               {displayValues.length > 0 && displayValuesFormated}
            </StyledSelect>

            {open && (           
                <StyledListContainer style={{width: props.menuWidth}} flagged={props.flagged}>
                    <StyledListBody>
                        <StyledListOuter>
                            <StyledListInner>
                                
                                <StyledMenu>
                                    {props.options.map((option, index) => {
                                    
                                        let classes = {width: "100%", marginRight: '50px'}
                                        let isSelected = "no"

                                        if (displayValues.length > 0) {
                                            displayValues.map((optionName) => {
                                                
                                                if(option === optionName) { 
                                                    classes = {
                                                        width: "100%", 
                                                        marginRight: '50px', 
                                                        backgroundColor: 'rgba(182, 207, 243, 0.805)'
                                                    }
                                                    isSelected = 'yes'
                                                }
                                            })
                                        }
                                        
                                        return (
                                            <StyledMenuItem 
                                                key={index} 
                                                onClick={() => handleValue("menuItem" + index)}
                                                data-value={option.name}
                                                id={"menuItem" + index}
                                                data-id={option.id}
                                                data-selected={isSelected}
                                                style={classes}
                                            >
                                                {option.name}
                                            </StyledMenuItem>
                                        )
                                    
                                    })}
                                </StyledMenu>

                            </StyledListInner>
                        </StyledListOuter>
                    </StyledListBody>
                </StyledListContainer>
            )}
        </DomNode>
    );
})

export default SelectMultiple;