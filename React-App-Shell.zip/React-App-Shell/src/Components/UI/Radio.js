import React from "react";
import styled from "styled-components";


/** HOW TO USE 
 * 
 * ID, Name, Label, Value
 * Disabled: disabled / NEED TO ADD THIS
*/


const Wrapper = styled.div`
    display: flex;
    height: 30px;
    min-width: 50px;
`

const RadioButton = styled.input`
    width: 24px;
    height: 24px;
    cursor: pointer;
    border: 2px solid ${(props) => props.flagged === "yes" ? "red;" : "#ccc !important;"}
    border-radius: 50%;
    transform: translateY(-0.075em);
    appearance: none;
    background-color: #FFF !important;
    padding: 2px;

    &:checked {
        border: 2px solid ${(props) =>  props.disabled ? "#ccc;" : props.flagged === "yes" ? "red;" : "#008CFF !important;"} 
    }

    &:checked::after {
        display: block;
        width: 100%;
        height: 100%;
        background: ${(props) => props.disabled ? "#ccc;" : props.flagged === "yes" ? "red;" : "#008CFF !important;"} 
        content: '';
        border: 2px solid ${(props) =>  props.disabled ? "#ccc;" : props.flagged === "yes" ? "red;" : "#008CFF !important;"}
        box-sizing: border-box;
        border-radius: 100%;
    }
`

const Label = styled.div`
    height: 14px;
    min-width: 50px;
    line-height: 30px;
    margin-left: 8px;
    color: ${(props) =>  props.disabled ? "#ccc;" : props.flagged === "yes" ? "red;" : "#5a5a5a;"}
    cursor: default;
    font-weight: 600;
`

export default function Radio2(props) {

    return (
        <Wrapper>
            <RadioButton 
                type="radio" 
                id={props.id} 
                name={props.name} 
                value={props.value} 
                flagged={props.flagged} 
                defaultChecked={props.checked}
                disabled={props.disabled}
            />
            <Label htmlFor={props.id} flagged={props.flagged}>{props.label}</Label>
        </Wrapper>
    )
}