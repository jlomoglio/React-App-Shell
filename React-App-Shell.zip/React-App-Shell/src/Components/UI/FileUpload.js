import React, { Fragment, useRef, useState } from "react";
import styled from 'styled-components';

const FileUploadField = styled.input`
    display: none;
`

const Wrapper = styled.div`
    height: auto;
    width: ${(props) => props.width ? props.width + ";" : "100%;"}
    border: 1px solid ${props => props.flagged === "yes" || props.error === "yes" ? "red;" : "#ccc;"}
    border-radius: 6px;
    display: flex;
`

const FakeInput = styled.input`
    font: inherit;
    font-size: 16px;
    color: ${(props) => props.flagged === "yes" || props.error === "yes" ? "red;" : "#5a5a5a;"}
    padding: 10px;
    width: 100%;
    max-width: 100%;
    height: 25px;
    border-top-style: hidden;
    border-right-style: hidden;
    border-left-style: hidden;
    border-bottom-style: hidden;
    border-top-left-radius: 6px;
    border-bottom-left-radius: 6px;
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    background-color: #fff;

    &:focus::-webkit-input-placeholder {
        color: transparent;
    }

    &:focus {
        outline: none;
    }
`

const Button = styled.div`
    width: auto;
    height: 45px;
    padding-left: 20px;
    padding-right: 20px;
    line-height: 45px;
    font-size: 14px;
    font-weight: 500;
    border-left: 1px solid ${(props) => props.flagged === "yes" || props.error === "yes" ? "red;" : "#ccc;"}
    border-top-right-radius: 6px;
    border-bottom-right-radius: 6px;
    background-color: #fff;
    color: ${(props) => props.flagged === "yes" || props.error === "yes" ? "red;" : "#5a5a5a;"}
    cursor: pointer;
`

export default function FileUpload(props) {

    const [uploadedFile, setUploadedFile] = useState();

    const hiddenFileInput = useRef();
    const FakeFileInput = useRef();

    const handleClick = () => {
        hiddenFileInput.current.click();
    }

    const handleChange = (event, onChange) => {
        const fileUploaded = event.target.files[0];

        props.handleFile(fileUploaded);
        props.onChange(onChange);

        FakeFileInput.current.value = hiddenFileInput.current.value.split("\\").pop();
    }

    return (
        <Fragment>
            
            <Wrapper width={props.width} flagged={props.flagged} error={props.error}>
                <FakeInput 
                    id={props.id}
                    type="text" 
                    ref={FakeFileInput} 
                    value={props.defaultValue}
                    placeholder="Upload file..."
                    onFocus={props.onFocus}
                    error={props.error}
                    flagged={props.flagged}
                    onChange={() => handleChange(props.onChange)}
                />
                <Button error={props.error} flagged={props.flagged} onClick={handleClick}>Browse</Button>
            </Wrapper>
            
            
            
            <FileUploadField
                id={props.id}
                type="file"
                name={props.name} 
                value={props.defaultValue}
                placeholder={props.placeholder}
                flagged={props.flagged}
                error={props.error} 
                ref={hiddenFileInput}
                onChange={handleChange}
                onFocus={handleChange}
            />
        </Fragment>
    )
}